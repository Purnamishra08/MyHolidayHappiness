<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Holidays Admin</title>
<link rel="icon" href="<?php echo base_url(); ?>assets/admin/img/fav-icon.png" sizes="16x16" type="image/png">
<link href="<?php echo base_url(); ?>assets/admin/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>assets/admin/assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>assets/admin/assets/pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>assets/admin/css/bootstrap-datepicker3.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>assets/admin/css/style.css?v=1" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>assets/admin/css/bootstrap-datepicker3.css" rel="stylesheet" type="text/css"/>

