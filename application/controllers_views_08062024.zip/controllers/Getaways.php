<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Getaways extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
		$this->load->database();
		$this->load->model('Common_model');
	}
	
 	public function index()
 	{		
 		$getawayurl = $this->uri->segment(3);
		if(!empty($getawayurl))
		{	
			$getawayurl = $this->db->escape($getawayurl);
			$validgetaway = $this->Common_model->noof_records("tagid","tbl_menutags","tag_url=$getawayurl and status='1'");
			if($validgetaway>0)
			{
				$data['getawaydata']=$this->Common_model->get_records("*","tbl_menutags","tag_url=$getawayurl and status='1'","");
				
				$this->load->view('getaways', $data);
			}
			else
				redirect(base_url(),'refresh');
		}
		else
			redirect(base_url(),'refresh');
	}
}


