<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bookings extends CI_Controller {

	public function __construct()
 	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
		$this->load->database();
		$this->load->model('Common_model');

		if($this->session->userdata('userid') == "")
		{
			redirect(base_url().'admin/logout','refresh');
		}
		
		$allusermodules = $this->session->userdata('allpermittedmodules');
		if(!(in_array(19, $allusermodules))) 
		{
			redirect(base_url().'admin/dashboard','refresh');
		}
 	}

	public function index()
	{
		$data['message'] = $this->session->flashdata('message');
		$data['bookings'] = $this->Common_model->get_records("*","tbl_bookings","", " booking_id DESC");
		$this->load->view('admin/manage_booking',$data);
	}
	
	public function delete()
	{
		$delid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("booking_id","tbl_bookings","booking_id='$delid'");
		if($noof_rec>0)
		{			
			$del = $this->Common_model->delete_records("tbl_bookings","booking_id=$delid");
			if($del)
			{
				$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Booking has been deleted successfully.</div>');
			}
			else
			{
				$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Booking could not deleted. Please try again.</div>');
			}
		}
		redirect(base_url().'admin/bookings','refresh');
	}
	

	public function view()
	{
		$data['message'] = $this->session->flashdata('message');
		$data['pmessage'] = $this->session->flashdata('pmessage');
		$viewid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("booking_id","tbl_bookings","booking_id='$viewid'");
		if($noof_rec>0)
		{
			$date = date("Y-m-d H:i:s");
		
			if (isset($_POST['btnSubBooking']) && !empty($_POST))
			{
				$this->form_validation->set_rules('booking_status','Status','trim|required');
            
				if ($this->form_validation->run() == true)
				{
					$bookingsts = $this->input->post('booking_status');

					$query_data = array(
						'booking_status'	=> $bookingsts,
						'modify_date'		=> $date
					);
					$updt_rec = $this->Common_model->update_records("tbl_bookings", $query_data," booking_id='$viewid'");
					if($updt_rec)
					{
						 $this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Booking status has been updated successfully.</div>');
					}
					else {						
						$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Booking status could not updated. Please try again.</div>');
					}
					redirect(base_url().'admin/bookings/view/'.$viewid,'refresh');
				}
				else
				{
					//set the flash data error message if there is one
					$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
				}
			}
			
			if (isset($_POST['btnsubpaymnt']) && !empty($_POST))
			{
				$this->form_validation->set_rules('paymntsts','Status','trim|required');
            
				if ($this->form_validation->run() == true)
				{
					$paymntsts = $this->input->post('paymntsts');
					$transnumber = $this->input->post('transnumber');

					$query_data = array(
						'payment_status'	=> $paymntsts,
						'transactin_id'		=> $transnumber,
						'modify_date'		=> $date
					);
					$updt_rec = $this->Common_model->update_records("tbl_bookings", $query_data,"booking_id='$viewid'");
					if($updt_rec)
					{
						 $this->session->set_flashdata('pmessage','<div class="successmsg notification"><i class="fa fa-check"></i> Payment Details has been updated successfully.</div>');
					}
					else {						
						$this->session->set_flashdata('pmessage','<div class="errormsg notification"><i class="fa fa-times"></i> Payment Details could not updated. Please try again.</div>');
					}
					redirect(base_url().'admin/bookings/view/'.$viewid,'refresh');
				}
				else
				{
					//set the flash data error message if there is one
					$data['pmessage'] = (validation_errors() ? validation_errors() : $this->session->flashdata('pmessage'));
				}
			}
			
			$data['bookings'] = $this->Common_model->get_records("*","tbl_bookings","booking_id=$viewid","");
			$this->load->view('admin/view_booking',$data);
		}
	}


}
 
	
