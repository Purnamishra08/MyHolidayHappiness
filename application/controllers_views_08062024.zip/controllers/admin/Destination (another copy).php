<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Destination extends CI_Controller {

	public function __construct()
 	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
		$this->load->database();
		$this->load->model('Common_model');

		if($this->session->userdata('userid') == "")
		{
			redirect(base_url().'admin/logout','refresh');
		}
		
		$allusermodules = $this->session->userdata('allpermittedmodules');
		if(!(in_array(6, $allusermodules))) 
		{
			redirect(base_url().'admin/dashboard','refresh');
		}
 	}

	public function index()
	{
		$data['message'] = $this->session->flashdata('message');
		$data['row'] = $this->Common_model->get_records("*","tbl_destination","", " destination_id DESC","","");
		$this->load->view('admin/manage_destination',$data);
	}

	public function add()
	{
		$data['message'] = $this->session->flashdata('message');
				
		if (isset($_POST['btnSubmit']) && !empty($_POST))
		{
			$this->form_validation->set_rules('destination_name', 'Destination Name', 'trim|required|xss_clean');
			
			$sess_userid = $this->session->userdata('userid');
			$date = date("Y-m-d H:i:s");
			if ($this->form_validation->run() == true)
			{
				$dname 		= $this->input->post('destination_name');
				$durl 		= $this->input->post('destination_url');
				$dtypes		= $this->input->post('destination_type');
				$dstate 	= $this->input->post('state');
				$dtrip      = $this->input->post('trip_duration');
				$dcity      = $this->input->post('nearest_city');
				$dtime      = $this->input->post('visit_time');
				$dpeak      = $this->input->post('peak_season');
				$dweather   = $this->input->post('weather_info');      
                $dmap       = $this->input->post('google_map');      
                $dprice     = $this->input->post('pick_drop_price');
				$ddesc 	    = $this->input->post('short_desc');
				$edestis 	= $this->input->post('edesti');
				$internet   = $this->input->post('internet_avl');
				$std        = $this->input->post('std_code');
				$lspeak     = $this->input->post('lng_spk');
				$mfest      = $this->input->post('mjr_fest');
				$getatagids      = $this->input->post('getatagid');
				$ntips      = $this->input->post('note_tips');
				$nearinfo 	= $this->input->post('near_info');
				$desttype_for_home 	= $this->input->post('desttype_for_home');
				$destiimg 	= $this->input->post('destiimg');
				$destiimg_thumb 	= $this->input->post('destiimg_thumb');
				
				
					
				
				$noof_duprec = $this->Common_model->noof_records("destination_name","tbl_destination","destination_name = '$dname' or destination_url = '$durl'");	
													
				if($noof_duprec < 1)	{	
					
				/* For destination banner*/	
				
				
				
					$destbanner_img = NULL;
					$destibanner = $_FILES['destiimg']['name'];
						if($destibanner != "")
						{
							$config['upload_path'] = './uploads/';
							$config['allowed_types'] = 'jpg|jpeg|png';
							$config['encrypt_name'] = FALSE;

							$destibanner = str_replace(" ", "_", $destibanner);
							$dBannerImage = $destibanner."_";

							$dbImage_name = 'destiBImg';
							$_FILES['destiimg']['name'] = $dBannerImage;
				
							$this->load->library('upload', $config);
							if ($this->upload->do_upload($dbImage_name))
							{
								$Image_path = $this->upload->data();
								$destbanner_img = $Image_path['file_name']; //$propertyImage;
								
								//resize:
								//$config_resize['image_library'] = 'gd2';
								$config['source_image'] = $this->upload->upload_path.$this->upload->file_name; 
								$config['maintain_ratio'] = FALSE;
								$config['width'] = 2000;
								$config['height'] = 336;
								$config['x_axis'] = 2000;
								$config['y_axis'] = 336;
								$this->load->library('image_lib', $config);
								
								$this->image_lib->initialize($config);
            					$this->image_lib->resize();
								/*********** Start for small Image Upload ***************/
								$config['new_image'] = './uploads/destination_thumb/' . $this->upload->file_name;
								$config['width'] = 300;
								$config['height'] = 225;
								$this->image_lib->initialize($config);
            					$this->image_lib->resize();
								/*********** End for small Image Upload ***************/
							}
						}
						
						$filename = $destbanner_img;
				
				
				
				
				
				
				
				
			
				
				
				/* for thumb image */
				if (isset($_FILES['destiimg_thumb']['name']) && !empty($_FILES['destiimg_thumb']['name']))
				{					
					$config['upload_path'] = './uploads/';
					$config['allowed_types'] = 'jpg|jpeg';
					$config['max_size'] = '0';
					$config['overwrite'] = FALSE;
					$config['encrypt_name'] = TRUE;
			
					$this->load->library('upload', $config);
					if($this->upload->do_upload('destiimg_thumb'))
					{						
						$this->load->library('image_lib');
						$photo_path = $this->upload->data();
						
						/*$array = explode('.',$rimage);
						$felement = current($array);
						$extension = end($array); 
				
				
						$unlinkimage = getcwd().'/uploads/'.$rimage;
						$unlink_thumbimage = getcwd().'/uploads/'.$felement.'_thumb.'.$extension;	*/
						
						
						$filename_thumb = $photo_path['file_name'].'_thumb';
						$config['create_thumb'] = TRUE;
						$config['thumb_marker'] = '_thumb';
						
						//resize:
						$config['source_image'] = $this->upload->upload_path.$this->upload->file_name;
						$config['maintain_ratio'] = FALSE;
						$config['width'] = 255;
						$config['height'] = 230;
						$this->image_lib->initialize($config);
						$this->image_lib->resize();
					}
					else
					{
						$filename_thumb = '';	
					}
				}
				else
				{
					$filename_thumb = '';
				}
				echo $filename_thumb ; exit;
				
				
				
				
				
				
				
				
				$insert_data = array(
					'destination_name'		=> $dname ,
					'destination_url'	    => $durl,
					// 'destination_type'		=> $dtype,
                    'state'		            => $dstate ,
					'trip_duration'	        => $dtrip ,  	
                    'nearest_city'	        => $dcity , 
                    'visit_time'	        => $dtime  ,  	
                    'peak_season'	        => $dpeak  ,
                    'weather_info'	        => $dweather   ,
                    'destiimg'	            => $filename   ,
                    'destiimg_thumb'	            => $filename_thumb   ,
                    'google_map'	        => $dmap  ,        
                    // 'other_info'	        => $dinfo  , 
                    'pick_drop_price'	    => $dprice  , 
                    'about_destination'	    => $ddesc  ,
                    'internet_availability' => $internet ,
                    'std_code'              => $std  ,
                    'language_spoken'       => $lspeak   ,
                    'major_festivals'       => $mfest    ,
                    'note_tips'             => $ntips     ,
					'status'		        => 1,
					'created_by'	        => $sess_userid,
					'created_date'	        => $date,
					'desttype_for_home'	        => $desttype_for_home
				);

				
				$insertdb = $this->Common_model->insert_records('tbl_destination', $insert_data);
				if($insertdb) 
				{
					$dinfo   = $this->input->post('other_info');
					$last_id = $this->db->insert_id();
                    
					
					foreach ( $edestis as $edesti ) {
						$insert_data = array(
						'destination_id' => $last_id ,
						'cat_id'	     => $edesti,
						);
						$insertdb = $this->Common_model->insert_records('tbl_destination_cats', $insert_data);
					}
					
					foreach ( $dtypes as $dtype ) {
						$insert_data = array(
						'destinationid'  => $last_id,
						'multdest_name'	 => $dtype,
						);
						$insertdb = $this->Common_model->insert_records('tbl_multdest_type', $insert_data);
					}
					
					foreach ( $getatagids as $getatagid ) {
						$insert_data = array(
						'type' => 1 ,
						'type_id' => $last_id ,
						'tagid'	     => $getatagid,
						);
						$insertdb = $this->Common_model->insert_records('tbl_tags', $insert_data);
					}



					if(!empty($nearinfo)){
					   foreach ($nearinfo as $nearinfos ) {
							$insert_data         = array(
							'destination_id'     => $last_id ,
							'placetype_name'	     => $nearinfos,
							);
							$insertdb = $this->Common_model->insert_records('tbl_place_type', $insert_data);
						}
					 }

				   if(!empty($dinfo)){
					foreach ( $dinfo as $otherinfos ) {
						$insert_data         = array(
						'destination_id'     => $last_id ,
						'simdest_name'	     => $otherinfos,
						);
						$insertdb = $this->Common_model->insert_records('tbl_simillar_dest', $insert_data);
					}
				   }


					
					$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Destination added successfully.</div>');
				}
				else
				{
					$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> User could not added. Please try again.</div>');
				}
			} else
				{
					$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> You have already added this destination, destination name or URL must be unique .</div>');
				}
				redirect(base_url().'admin/destination/add','refresh');
			}
			else
			{
				//set the flash data error message if there is one
				$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
			}
		}
		$this->load->view('admin/add_destination',$data);
	}

	public function edit()
	{
		$editid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("destination_id","tbl_destination","destination_id='$editid' ");
		if($noof_rec>0)
		{
			$data['message'] = $this->session->flashdata('message');
			$data['row'] = $this->Common_model->get_records("*","tbl_destination","destination_id='$editid'","");
			if (isset($_POST['btnSubmit']) && !empty($_POST))
			{
				$this->form_validation->set_rules('destination_name', 'destination_name', 'trim|required|xss_clean');
				$this->form_validation->set_rules('destination_url',  'destination_url', 'trim|required|xss_clean');
				//$this->form_validation->set_rules('destination_type', 'destination_type.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('state', 'state.',  'trim|required|xss_clean');
				$this->form_validation->set_rules('trip_duration',    'trip_duration.', 'trim|required|xss_clean');
				

				$sess_userid = $this->session->userdata('userid');
				$date = date("Y-m-d H:i:s");
				if ($this->form_validation->run() == true)
				{
					
				$dname 		= $this->input->post('destination_name');
				$durl 		= $this->input->post('destination_url');
				//$dtype 		= $this->input->post('destination_type');
				$dstate 	= $this->input->post('state');
				$dtrip      = $this->input->post('trip_duration');
				$dcity      = $this->input->post('nearest_city');
				$dtime      = $this->input->post('visit_time');
				$dpeak      = $this->input->post('peak_season');
				$dweather   = $this->input->post('weather_info');      
                $drating    = $this->input->post('rating'); 
                $dmap       = $this->input->post('google_map');      
                // $dinfo      = $this->input->post('other_info');
                $dprice     = $this->input->post('pick_drop_price');
				$ddesc 	    = $this->input->post('short_desc');
				$internet   = $this->input->post('internet_avl');
				$std        = $this->input->post('std_code');
				$lspeak     = $this->input->post('lng_spk');
				$mfest      = $this->input->post('mjr_fest');
				$ntips      = $this->input->post('note_tips');
				$desttype_for_home      = $this->input->post('desttype_for_home');
				$gettagids      = $this->input->post('gettagid');
				$edestis      = $this->input->post('edesti');
				
				$destiimg      = $this->input->post('destiimg');
				
				$noof_duprec = $this->Common_model->noof_records("destination_name","tbl_destination","(destination_name = '$dname' or destination_url = '$durl') and destination_id!='$editid' ");	
													
				if($noof_duprec < 1)	{
					$rimage = $this->Common_model->showname_fromid("destiimg","tbl_destination","destination_id='$editid'");
					
				if (isset($_FILES) && !empty($_FILES))
				{					
					$config['upload_path'] = './uploads/';
					$config['allowed_types'] = 'jpg|jpeg';
					$config['max_size'] = '0';
					$config['overwrite'] = FALSE;
					$config['encrypt_name'] = TRUE;
			
					$this->load->library('upload', $config);
					if($this->upload->do_upload('destiimg'))
					{	
						
						$array = explode('.',$rimage);
						$felement = current($array);
						$extension = end($array); 
				
				
						$unlinkimage = getcwd().'/uploads/'.$rimage;
						$unlink_thumbimage = getcwd().'/uploads/'.$felement.'_thumb.'.$extension;	
						
						if (file_exists($unlinkimage) && !is_dir($unlinkimage))
						{
							unlink($unlinkimage);
						}
												
						//for thumb						
						if (file_exists($unlink_thumbimage) && !is_dir($unlink_thumbimage))
						{
							unlink($unlink_thumbimage);
						}
											
						$this->load->library('image_lib');
						$photo_path = $this->upload->data();
						
						$filename = $photo_path['file_name'];
					
						$config['create_thumb'] = TRUE;
						$config['thumb_marker'] = '_thumb';
						
						//resize:
						$config['new_image'] = $this->upload->upload_path.$this->upload->file_name;
						$config['source_image'] = $this->upload->upload_path.$this->upload->file_name;
						$config['maintain_ratio'] = FALSE;
						$config['width'] = 268;
						$config['height'] = 180;
						$this->image_lib->initialize($config);
						$this->image_lib->resize();
					}
					else
					{
						$filename = $rimage;	
					}
				}
				else
				{
					$filename = $rimage;
				}

					
				$update_data = array(
					'destination_name'		=> $dname ,
					'destination_url'	    => $durl,
					//'destination_type'		=> $dtype,
                    'state'		            => $dstate ,
					'trip_duration'	        => $dtrip ,  	
                    'nearest_city'	        => $dcity , 
                    'visit_time'	        => $dtime  ,  	
                    'peak_season'	        => $dpeak  ,
                    'weather_info'	        => $dweather   ,
                    'destiimg'	            => $filename   ,
                    'google_map'	        => $dmap  ,        
                    // 'other_info'	        => $dinfo  , 
                    'pick_drop_price'	    => $dprice  , 
                    'about_destination'	    => $ddesc  ,
                    'internet_availability' => $internet ,
                    'std_code'              => $std  ,
                    'language_spoken'       => $lspeak   ,
                    'major_festivals'       => $mfest    ,
                    'note_tips'             => $ntips     ,
					'updated_by'	        => $sess_userid,
					'updated_date'	        => $date,
					'desttype_for_home'	        => $desttype_for_home

					        	);
						
					$updatedb = $this->Common_model->update_records('tbl_destination',$update_data,"destination_id=$editid");
						if($updatedb)
						{

                        $type_id = $this->input->post('destination_type');
                        $tagid   = $this->input->post('edesti');
                        $placeid   = $this->input->post('near_info');
                        $destination_id   = $this->input->post('other_info');
						$datee = date("Y-m-d H:i:s");   
                        

                        $this->Common_model->delete_records("tbl_multdest_type","destinationid=$editid");
						if (($type_id != '')) {
							$countmtt = sizeof($type_id);
							for($k=0; $k<$countmtt; $k++)
							{
								$vatag = $type_id[$k];
								$valltagid = $vatag;								

								$noof_duprc1 = $this->Common_model->noof_records("destinationid, multdest_id", "tbl_multdest_type", "destinationid='$editid' and multdest_name='$vatag'");
								if($noof_duprc1<1)
								{
									$query_datachild1 = array(
										'destinationid'	=> $editid,
										'multdest_name'		=> $vatag,
										// 'updated_date'	=> $datee							
									);
									$insert_record1 = $this->Common_model->insert_records("tbl_multdest_type", $query_datachild1);
								}
							}  
						}  


                      $this->Common_model->delete_records("tbl_destination_cats","destination_id=$editid");
                      
						if (($edestis != '')) {
							$countmtt = sizeof($edestis);
							for($k=0; $k < $countmtt; $k++)
							{
								$vaatag = $edestis[$k];	
									$query_datachild1 = array(
										'destination_id'	=> $editid,
										'cat_id'		    => $vaatag							
									);
								$insert_record1 = $this->Common_model->insert_records("tbl_destination_cats", $query_datachild1);
							}  
						} 
						
						
					  $this->Common_model->delete_records("tbl_tags","type_id=$editid");
						if (($gettagids != '')) {														
							$countmtt = sizeof($gettagids);
							for($k=0; $k < $countmtt; $k++)
							{
								$vaatag = $gettagids[$k];
								$valltagid = $vaatag;
																
									$query_datachild2 = array(
										'type'		=> 1,
										'type_id'	=> $editid,
										'tagid'		=> $vaatag							
									);
									//print_r($query_datachild2); 
									$insert_record1 = $this->Common_model->insert_records("tbl_tags", $query_datachild2);
							}  
						} 
					
						
                       $this->Common_model->delete_records("tbl_place_type","destination_id=$editid");
                      if (($placeid != '')) {
							$countmtt = sizeof($placeid);
							for($k=0; $k<$countmtt; $k++)
							{
								$placetag = $placeid[$k];
								$placetagid = $placetag;								

								$noof_duprc1 = $this->Common_model->noof_records("destination_id, placetypeid", "tbl_place_type", "destination_id='$editid' and placetype_name='$placetag'");
								if($noof_duprc1<1)
								{
									$query_datachild1 = array(
										'destination_id'	=> $editid,
										'placetype_name'		    => $placetag				
									);
									$insert_record1 = $this->Common_model->insert_records("tbl_place_type", $query_datachild1);
								}
							}  
						} 
						
                        $this->Common_model->delete_records("tbl_simillar_dest","destination_id=$editid");

						 if (($destination_id != '')) {
							$countmtt = sizeof($destination_id);
							for($k=0; $k<$countmtt; $k++)
							{
								$simdest = $destination_id[$k];
								$simdesttid = $simdest;								

								$noof_duprc1 = $this->Common_model->noof_records("destination_id, simdest_id", "tbl_simillar_dest", "destination_id='$editid' and simdest_name='$simdest'");
								if($noof_duprc1<1)
								{
									$query_datachild1 = array(
										'destination_id'	=> $editid,
										'simdest_name'		    => $simdest,
										//'updated_date'	=> $datee							
									);
									$insert_record1 = $this->Common_model->insert_records("tbl_simillar_dest", $query_datachild1);
								}
							}  
						}  

							
						$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Destination edited successfully.</div>');
						}
						else
						{	
							$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Destination could not edited. Please try again.</div>');
						}
					}
						else
						{	
							$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i>  You have already added this destination, destination name or URL must be unique .</div>');
						}
					
					redirect(base_url().'admin/destination/edit/'.$editid,'refresh');
				}
				else
				{
					//set the flash data error message if there is one
					$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
				}
			}
			$this->load->view('admin/edit_destination', $data);
		}
		else
			redirect(base_url().'admin/destination','refresh');
	}





	// public function delete()
	// {
	// 	$delid = $this->uri->segment(4);
	// 	$noof_rec = $this->Common_model->noof_records("destination_id","tbl_destination","destination_id='$delid'");
	// 	if($noof_rec>0)
	// 	{	
	// 		$del = $this->Common_model->delete_records("tbl_destination","destination_id=$delid");
	// 		if($del)
	// 		{
				
				
	// 				$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Destination has been deleted successfully.</div>');
				
	// 		}
	// 		else
	// 		{
	// 			$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Destination could not deleted. Please try again.</div>');
	// 		}
	// 	}
	// 	redirect(base_url().'admin/destination','refresh');
	// }


	public function delete_apptag(){
    	$delid = $this->uri->segment(4);
    	//echo $delid;
    	$posid = $this->input->post('posid');
    	$ta_id = $this->input->post('ta_id');

		$noof_rec = $this->Common_model->noof_records("multdest_id","tbl_multdest_type","destinationid='$posid' and multdest_id='$ta_id' ");
		if($noof_rec>0){
			$del_rec = $this->Common_model->delete_records("tbl_multdest_type","destinationid='$posid' and multdest_id='$ta_id' ");
			echo 'Type Removed Successfully ';
		}		    	
    }


    public function delete_desttag(){
    	$delid = $this->uri->segment(4);
    	$possid = $this->input->post('possid');
    	$tat_id = $this->input->post('tat_id');
		$noof_rec = $this->Common_model->noof_records("tag_id","tbl_destination_tag","destination_id='$possid' and tag_id='$tat_id' ");
		if($noof_rec>0){
			$del_rec = $this->Common_model->delete_records("tbl_destination_tag","destination_id='$possid' and tag_id='$tat_id' ");
			echo 'Tag Removed Successfully ';
		}		    	
    }

public function delete_destination()
	{
		$delid = $this->uri->segment(4);
        $noof_rec = $this->Common_model->noof_records("destination_id","tbl_destination","destination_id='$delid'");
        if($noof_rec>0)
        {
			
			// $proimg=$this->Common_model->showname_fromid("destiimg","tbl_destination","destination_id='$delid'");
            
			// if($proimg!='' && $proimg!=' ')
   //              $pathimgnm="uploads/$proimg";
   //          else
   //              $pathimgnm="";
   //          $del_dest_tag = $this->Common_model->delete_records("tbl_destination_tag","destination_id=$delid");
   //          $del_multdest_type = $this->Common_model->delete_records("tbl_multdest_type","destinationid=$delid");
			// $del_dest_place = $this->Common_model->delete_records("tbl_place_type","destination_id=$delid");
   //          $del = $this->Common_model->delete_records("tbl_destination","destination_id=$delid");



            $proimg=$this->Common_model->showname_fromid("destiimg","tbl_destination","destination_id='$delid'");				
			  $unlinkimage = getcwd().'/uploads/'.$proimg;
				$array = explode('.',$proimg);
				$felement = current($array);
				$extension = end($array); 
				
				$unlinkimage = getcwd().'/uploads/'.$proimg;
				$unlink_thumbimage = getcwd().'/uploads/'.$felement.'_thumb.'.$extension;		
														
					if (file_exists($unlinkimage) && !is_dir($unlinkimage))
					{
						unlink($unlinkimage);
					}
					if (file_exists($unlink_thumbimage) && !is_dir($unlink_thumbimage))
					{
						unlink($unlink_thumbimage);
					}
			
            $del_dest_tag = $this->Common_model->delete_records("tbl_destination_cats","destination_id=$delid");
            $del_multdest_type = $this->Common_model->delete_records("tbl_multdest_type","destinationid=$delid");
            $del_simillar_dest = $this->Common_model->delete_records("tbl_simillar_dest","destination_id=$delid");
			$del_dest_place = $this->Common_model->delete_records("tbl_place_type","destination_id=$delid");
            $del = $this->Common_model->delete_records("tbl_destination","destination_id=$delid");



            if($del)
            {              
                /*if($pathimgnm!='' && $pathimgnm!=' ')
                {
                    if(file_exists($pathimgnm))
                        unlink($pathimgnm);
                } */              

                $this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Destination has been deleted successfully.</div>');
            }
            else
            {
                $this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Destination could not deleted. Please try again.</div>');
            }
        }
		redirect(base_url().'admin/destination','refresh');
	}
	







	public function changestatus()
	{
		$stsid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("destination_id","tbl_destination","destination_id='$stsid' ");
		if($noof_rec>0)
		{			
			$status = $this->Common_model->showname_fromid("status","tbl_destination","destination_id=$stsid");
			if($status==1)
				$updatedata = array('status' => 0);
			else
				$updatedata = array('status' => 1);
			$updatestatus = $this->Common_model->update_records("tbl_destination",$updatedata,"destination_id=$stsid");
			if($updatestatus)
				echo $status;
			else
				echo "error";			
		}
		exit();
	}

    public function view()
	{
		$data['message'] = $this->session->flashdata('message');
		$viewid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("destination_id","tbl_destination","destination_id='$viewid'");
		if($noof_rec>0)
		{
			$data['dstype'] = $this->Common_model->get_records("*","tbl_destination","destination_id=$viewid","");
			$this->load->view('admin/view_destination',$data);
		}
	}



	 function ddoo_upload($filename)
	 	{
	 		$config['upload_path'] = './uploads/';
	 		$config['allowed_types'] = 'jpg|jpeg|png|gif';
	 		$config['max_size'] = '0';
			$config['overwrite'] = FALSE;
	 		$config['encrypt_name'] = TRUE;
	 		$config['width'] = 732;
	 		$config['height'] = 485;
			//$config['file_name'] =time().'-'.date("Y-m-d").'-'.$_FILES['filename']['name'];

	 		$this->load->library('upload', $config);
	 		$this->upload->initialize($config);
			if ($this->upload->do_upload($filename)) {
	 			$data = $this->upload->data();
	 			$filename = $data['file_name'];
	 			return $filename;
			} else {			
	 			//echo $this->upload->display_errors();die();
	 			return NULL;
	 		}
	 	}	









}
 
	
