<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Destination extends CI_Controller {

	public function __construct()
 	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
		$this->load->database();
		$this->load->model('Common_model');

		if($this->session->userdata('userid') == "")
		{
			redirect(base_url().'admin/logout','refresh');
		}
		
		$allusermodules = $this->session->userdata('allpermittedmodules');
		if(!(in_array(6, $allusermodules))) 
		{
			redirect(base_url().'admin/dashboard','refresh');
		}
 	}

	public function index()
	{
		$data['message'] = $this->session->flashdata('message');
		$data['row'] = $this->Common_model->get_records("*","tbl_destination","", " destination_id DESC","","");
		$this->load->view('admin/manage_destination',$data);
	}

	public function add()
	{
		$data['message'] = $this->session->flashdata('message');



		
		if (isset($_POST['btnSubmit']) && !empty($_POST))
		{
			$this->form_validation->set_rules('destination_name', 'Destination Name', 'trim|required|xss_clean');
			
			$sess_userid = $this->session->userdata('userid');
			$date = date("Y-m-d H:i:s");
			if ($this->form_validation->run() == true)
			{
				$dname 		= $this->input->post('destination_name');
				$durl 		= $this->input->post('destination_url');
				$dtypes		= $this->input->post('destination_type');
				$dstate 	= $this->input->post('state');
				$dtrip      = $this->input->post('trip_duration');
				$dcity      = $this->input->post('nearest_city');
				$dtime      = $this->input->post('visit_time');
				$dpeak      = $this->input->post('peak_season');
				$dweather   = $this->input->post('weather_info');      
                $dmap       = $this->input->post('google_map');      
                $dinfo      = $this->input->post('other_info');
                $dprice     = $this->input->post('pick_drop_price');
				$ddesc 	    = $this->input->post('short_desc');
				$edestis 	= $this->input->post('edesti');
				$internet   = $this->input->post('internet_avl');
				$std        = $this->input->post('std_code');
				$lspeak     = $this->input->post('lng_spk');
				$mfest      = $this->input->post('mjr_fest');
				$ntips      = $this->input->post('note_tips');
				$nearinfo 	= $this->input->post('near_info');


					

				if (isset($_FILES['destiimg']) && $_FILES['destiimg']['name'] != '') {
				 	$destpic = $this->ddoo_upload('destiimg');
				} else {
				 	$destpic = NULL;
				 }              
               
				
				$insert_data = array(
					'destination_name'		=> $dname ,
					'destination_url'	    => $durl,
					// 'destination_type'		=> $dtype,
                    'state'		            => $dstate ,
					'trip_duration'	        => $dtrip ,  	
                    'nearest_city'	        => $dcity , 
                    'visit_time'	        => $dtime  ,  	
                    'peak_season'	        => $dpeak  ,
                    'weather_info'	        => $dweather   ,
                    'destiimg'	            => $destpic   ,
                    'google_map'	        => $dmap  ,        
                    'other_info'	        => $dinfo  , 
                    'pick_drop_price'	    => $dprice  , 
                    'about_destination'	    => $ddesc  ,
                    'internet_availability' => $internet ,
                    'std_code'              => $std  ,
                    'language_spoken'       => $lspeak   ,
                    'major_festivals'       => $mfest    ,
                    'note_tips'             => $ntips     ,
					'status'		        => 1,
					'created_by'	        => $sess_userid,
					'created_date'	        => $date
				);

				
				$insertdb = $this->Common_model->insert_records('tbl_destination', $insert_data);
				if($insertdb)
				{
					$last_id = $this->db->insert_id();

					foreach ( $edestis as $edesti ) {
						$insert_data = array(
						'destination_id' => $last_id ,
						'tag_name'	     => $edesti,
						);
						$insertdb = $this->Common_model->insert_records('tbl_destination_tag', $insert_data);
					}

					foreach ( $dtypes as $dtype ) {
						$insert_data = array(
						'destinationid' => $last_id ,
						'multdest_name'	     => $dtype,
						);
						$insertdb = $this->Common_model->insert_records('tbl_multdest_type', $insert_data);
					}




                   foreach ( $nearinfo as $nearinfos ) {
						$insert_data         = array(
						'destination_id'     => $last_id ,
						'placetype_name'	     => $nearinfos,
						);
						$insertdb = $this->Common_model->insert_records('tbl_place_type', $insert_data);
					}


					
					$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Destination added successfully.</div>');
				}
				else
				{
					$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> User could not added. Please try again.</div>');
				}
				redirect(base_url().'admin/destination/add','refresh');
			}
			else
			{
				//set the flash data error message if there is one
				$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
			}
		}
		$this->load->view('admin/add_destination',$data);
	}

	public function edit()
	{
		$editid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("destination_id","tbl_destination","destination_id='$editid' ");
		if($noof_rec>0)
		{
			$data['message'] = $this->session->flashdata('message');
			$data['row'] = $this->Common_model->get_records("*","tbl_destination","destination_id='$editid'","");
			if (isset($_POST['btnSubmit']) && !empty($_POST))
			{
				$this->form_validation->set_rules('destination_name', 'destination_name', 'trim|required|xss_clean');
				$this->form_validation->set_rules('destination_url',  'destination_url', 'trim|required|xss_clean');
				//$this->form_validation->set_rules('destination_type', 'destination_type.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('state', 'state.',  'trim|required|xss_clean');
				$this->form_validation->set_rules('trip_duration',    'trip_duration.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('nearest_city',     'nearest_city.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('visit_time',       'visit_time.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('peak_season',      'peak_season.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('weather_info',     'weather_info.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('google_map',       'google_map.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('other_info',       'other_info.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('pick_drop_price',  'pick_drop_price.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('short_desc',       'short_desc.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('internet_avl',     'internet_avl.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('std_code',         'std_code.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('lng_spk',          'lng_spk.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('mjr_fest',         'mjr_fest.', 'trim|required|xss_clean');
				$this->form_validation->set_rules('note_tips',        'note_tips.', 'trim|required|xss_clean');



				
				$sess_userid = $this->session->userdata('userid');
				$date = date("Y-m-d H:i:s");
				if ($this->form_validation->run() == true)
				{
					
				$dname 		= $this->input->post('destination_name');
				$durl 		= $this->input->post('destination_url');
				//$dtype 		= $this->input->post('destination_type');
				$dstate 	= $this->input->post('state');
				$dtrip      = $this->input->post('trip_duration');
				$dcity      = $this->input->post('nearest_city');
				$dtime      = $this->input->post('visit_time');
				$dpeak      = $this->input->post('peak_season');
				$dweather   = $this->input->post('weather_info');      
                $drating    = $this->input->post('rating'); 
                $dmap       = $this->input->post('google_map');      
                $dinfo      = $this->input->post('other_info');
                $dprice     = $this->input->post('pick_drop_price');
				$ddesc 	    = $this->input->post('short_desc');
				$internet   = $this->input->post('internet_avl');
				$std        = $this->input->post('std_code');
				$lspeak     = $this->input->post('lng_spk');
				$mfest      = $this->input->post('mjr_fest');
				$ntips      = $this->input->post('note_tips');

				if (isset($_FILES['destiimg']) && $_FILES['destiimg']['name'] != '') {
						$proimg = $this->ddoo_upload('destiimg');
						 
						$brwsimgname=$this->Common_model->showname_fromid("destiimg","tbl_destination","destination_id='$editid'");
						if($brwsimgname!='' && $brwsimgname!=' ')
						{ 
							$pathimgnm="uploads/$brwsimgname";
							if(file_exists($pathimgnm))
								unlink($pathimgnm);
						}
					} else {
						$proimg=$this->Common_model->showname_fromid("destiimg","tbl_destination","destination_id='$editid'");
					} 

					
				$update_data = array(
					'destination_name'		=> $dname ,
					'destination_url'	    => $durl,
					//'destination_type'		=> $dtype,
                    'state'		            => $dstate ,
					'trip_duration'	        => $dtrip ,  	
                    'nearest_city'	        => $dcity , 
                    'visit_time'	        => $dtime  ,  	
                    'peak_season'	        => $dpeak  ,
                    'weather_info'	        => $dweather   ,
                    'destiimg'	            => $proimg   ,
                    'google_map'	        => $dmap  ,        
                    'other_info'	        => $dinfo  , 
                    'pick_drop_price'	    => $dprice  , 
                    'about_destination'	    => $ddesc  ,
                    'internet_availability' => $internet ,
                    'std_code'              => $std  ,
                    'language_spoken'       => $lspeak   ,
                    'major_festivals'       => $mfest    ,
                    'note_tips'             => $ntips     ,
					'updated_by'	        => $sess_userid,
					'updated_date'	        => $date

					        	);
						
					$updatedb = $this->Common_model->update_records('tbl_destination',$update_data,"destination_id=$editid");
						if($updatedb)
						{

                        $type_id = $this->input->post('destination_type');
                        $tagid   = $this->input->post('edesti');
                         $placeid   = $this->input->post('near_info');
						$datee = date("Y-m-d H:i:s");   

						if (($type_id != '')) {
							$countmtt = sizeof($type_id);
							for($k=0; $k<$countmtt; $k++)
							{
								$vatag = $type_id[$k];
								$valltagid = $vatag;								

								$noof_duprc1 = $this->Common_model->noof_records("destinationid, multdest_id", "tbl_multdest_type", "destinationid='$editid' and multdest_name='$vatag'");
								if($noof_duprc1<1)
								{
									$query_datachild1 = array(
										'destinationid'	=> $editid,
										'multdest_name'		=> $vatag,
										// 'updated_date'	=> $datee							
									);
									$insert_record1 = $this->Common_model->insert_records("tbl_multdest_type", $query_datachild1);
								}
							}  
						}  

						if (($tagid != '')) {
							$countmtt = sizeof($tagid);
							for($k=0; $k<$countmtt; $k++)
							{
								$vaatag = $tagid[$k];
								$valltagid = $vaatag;								

								$noof_duprc1 = $this->Common_model->noof_records("destination_id, tag_id", "tbl_destination_tag", "destination_id='$editid' and tag_name='$vaatag'");
								if($noof_duprc1<1)
								{
									$query_datachild1 = array(
										'destination_id'	=> $editid,
										'tag_name'		    => $vaatag,
										//'updated_date'	=> $datee							
									);
									$insert_record1 = $this->Common_model->insert_records("tbl_destination_tag", $query_datachild1);
								}
							}  
						}  



                      if (($placeid != '')) {
							$countmtt = sizeof($placeid);
							for($k=0; $k<$countmtt; $k++)
							{
								$placetag = $placeid[$k];
								$placetagid = $placetag;								

								$noof_duprc1 = $this->Common_model->noof_records("destination_id, placetypeid", "tbl_place_type", "destination_id='$editid' and placetype_name='$placetag'");
								if($noof_duprc1<1)
								{
									$query_datachild1 = array(
										'destination_id'	=> $editid,
										'placetype_name'		    => $placetag,
										//'updated_date'	=> $datee							
									);
									$insert_record1 = $this->Common_model->insert_records("tbl_place_type", $query_datachild1);
								}
							}  
						}  









							
						$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Destination edited successfully.</div>');
						}
						else
						{	
							$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Destination could not edited. Please try again.</div>');
						}
					
					redirect(base_url().'admin/destination/edit/'.$editid,'refresh');
				}
				else
				{
					//set the flash data error message if there is one
					$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
				}
			}
			$this->load->view('admin/edit_destination', $data);
		}
		else
			redirect(base_url().'admin/destination','refresh');
	}





	// public function delete()
	// {
	// 	$delid = $this->uri->segment(4);
	// 	$noof_rec = $this->Common_model->noof_records("destination_id","tbl_destination","destination_id='$delid'");
	// 	if($noof_rec>0)
	// 	{	
	// 		$del = $this->Common_model->delete_records("tbl_destination","destination_id=$delid");
	// 		if($del)
	// 		{
				
				
	// 				$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Destination has been deleted successfully.</div>');
				
	// 		}
	// 		else
	// 		{
	// 			$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Destination could not deleted. Please try again.</div>');
	// 		}
	// 	}
	// 	redirect(base_url().'admin/destination','refresh');
	// }


public function delete_apptag(){
    	$delid = $this->uri->segment(4);
    	//echo $delid;
    	$posid = $this->input->post('posid');
    	$ta_id = $this->input->post('ta_id');

		$noof_rec = $this->Common_model->noof_records("multdest_id","tbl_multdest_type","destinationid='$posid' and multdest_id='$ta_id' ");
		if($noof_rec>0){
			$del_rec = $this->Common_model->delete_records("tbl_multdest_type","destinationid='$posid' and multdest_id='$ta_id' ");
			echo 'Type Removed Successfully ';
		}		    	
    }





    public function delete_desttag(){
    	$delid = $this->uri->segment(4);
    	$possid = $this->input->post('possid');
    	$tat_id = $this->input->post('tat_id');
		$noof_rec = $this->Common_model->noof_records("tag_id","tbl_destination_tag","destination_id='$possid' and tag_id='$tat_id' ");
		if($noof_rec>0){
			$del_rec = $this->Common_model->delete_records("tbl_destination_tag","destination_id='$possid' and tag_id='$tat_id' ");
			echo 'Tag Removed Successfully ';
		}		    	
    }


public function delete_destination()
	{
		$delid = $this->uri->segment(4);
        $noof_rec = $this->Common_model->noof_records("destination_id","tbl_destination","destination_id='$delid'");
        if($noof_rec>0)
        {
			
			// $proimg=$this->Common_model->showname_fromid("destiimg","tbl_destination","destination_id='$delid'");
            
			// if($proimg!='' && $proimg!=' ')
   //              $pathimgnm="uploads/$proimg";
   //          else
   //              $pathimgnm="";
   //          $del_dest_tag = $this->Common_model->delete_records("tbl_destination_tag","destination_id=$delid");
   //          $del_multdest_type = $this->Common_model->delete_records("tbl_multdest_type","destinationid=$delid");
			// $del_dest_place = $this->Common_model->delete_records("tbl_place_type","destination_id=$delid");
   //          $del = $this->Common_model->delete_records("tbl_destination","destination_id=$delid");



            $proimg=$this->Common_model->showname_fromid("destiimg","tbl_destination","destination_id='$delid'");				
			  $unlinkimage = getcwd().'/uploads/'.$proimg;
				$array = explode('.',$proimg);
				$felement = current($array);
				$extension = end($array); 
				
				$unlinkimage = getcwd().'/uploads/'.$proimg;
				$unlink_thumbimage = getcwd().'/uploads/'.$felement.'_thumb.'.$extension;		
														
					if (file_exists($unlinkimage) && !is_dir($unlinkimage))
					{
						unlink($unlinkimage);
					}
					if (file_exists($unlink_thumbimage) && !is_dir($unlink_thumbimage))
					{
						unlink($unlink_thumbimage);
					}
			
            $del_dest_tag = $this->Common_model->delete_records("tbl_destination_tag","destination_id=$delid");
            $del_multdest_type = $this->Common_model->delete_records("tbl_multdest_type","destinationid=$delid");
			$del_dest_place = $this->Common_model->delete_records("tbl_place_type","destination_id=$delid");
            $del = $this->Common_model->delete_records("tbl_destination","destination_id=$delid");



            if($del)
            {              
                /*if($pathimgnm!='' && $pathimgnm!=' ')
                {
                    if(file_exists($pathimgnm))
                        unlink($pathimgnm);
                } */              

                $this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Product has been deleted successfully.</div>');
            }
            else
            {
                $this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Product could not deleted. Please try again.</div>');
            }
        }
		redirect(base_url().'admin/destination','refresh');
	}
	







	public function changestatus()
	{
		$stsid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("destination_id","tbl_destination","destination_id='$stsid' ");
		if($noof_rec>0)
		{			
			$status = $this->Common_model->showname_fromid("status","tbl_destination","destination_id=$stsid");
			if($status==1)
				$updatedata = array('status' => 0);
			else
				$updatedata = array('status' => 1);
			$updatestatus = $this->Common_model->update_records("tbl_destination",$updatedata,"destination_id=$stsid");
			if($updatestatus)
				echo $status;
			else
				echo "error";			
		}
		exit();
	}

public function view()
	{
		$data['message'] = $this->session->flashdata('message');
		$viewid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("destination_id","tbl_destination","destination_id='$viewid'");
		if($noof_rec>0)
		{
			$data['dstype'] = $this->Common_model->get_records("*","tbl_destination","destination_id=$viewid","");
			$this->load->view('admin/view_destination',$data);
		}
	}



function ddoo_upload($filename)
	{
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'jpg|jpeg|png|gif';
		$config['max_size'] = '0';
		$config['overwrite'] = FALSE;
		$config['encrypt_name'] = TRUE;
		$config['width'] = 732;
		$config['height'] = 485;
		//$config['file_name'] =time().'-'.date("Y-m-d").'-'.$_FILES['filename']['name'];

		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		if ($this->upload->do_upload($filename)) {
			$data = $this->upload->data();
			$filename = $data['file_name'];
			return $filename;
		} else {			
			//echo $this->upload->display_errors();die();
			return NULL;
		}
	}









}
 
	