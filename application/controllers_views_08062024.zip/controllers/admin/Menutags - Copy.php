<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menutags extends CI_Controller {

	public function __construct()
 	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');	
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');	
		$this->load->database();
		$this->load->model('Common_model');
		$this->load->library('pagination');
		if($this->session->userdata('userid') == "")
		{
			redirect(base_url().'admin/logout','refresh');
		}		
		
 	}

	public function index()
	{
		$data['messageadd'] = $this->session->flashdata('messageadd');		
		$data['row'] = $this->Common_model->get_records("*","tbl_menutags","","tagid DESC","","");

		/*Add price*/

		if (isset($_POST['btnSubmitcats']) && !empty($_POST))
		{			
			$this->form_validation->set_rules('menuid', 'menuid', 'trim|required|xss_clean');
			$this->form_validation->set_rules('catId', 'catId', 'trim|required|xss_clean');
			$this->form_validation->set_rules('tag_name', 'tagname', 'trim|required|xss_clean');		
			
			if ($this->form_validation->run() == true)
			{				
				$menuid = $this->input->post('menuid');				 
				$catId = $this->input->post('catId');	
				$tag_name = $this->input->post('tag_name');	
				$about_tour = $this->input->post('about_tour');	

				$noof_duprec = $this->Common_model->noof_records("tagid","tbl_menutags","menuid = $menuid and tag_name ='$tag_name'");				
				$date = date("Y-m-d H:i:s");
				if($noof_duprec < 1)
					{
						$insert_data = array(
							'menuid'	=> $menuid,
							'cat_id'	=> $catId,
							'tag_name'	=> $tag_name,
							'about_tour'=> $about_tour,
							'created'	=> $date,
							'status'	=> 1					
						);				

					$insertdb = $this->Common_model->insert_records('tbl_menutags', $insert_data);
					if($insertdb) {
						$this->session->set_flashdata('messageadd','<div class="successmsg notification"><i class="fa fa-check"></i> Tag added successfully.</div>');
					} else {
						$this->session->set_flashdata('messageadd','<div class="errormsg notification"><i class="fa fa-times"></i> Tag could not added. Please try again.</div>');
					}
				}
			else
				{
					$this->session->set_flashdata('messageadd','<div class="errormsg notification"><i class="fa fa-times"></i> You have already added this tag to this menus and category.</div>');
				}
				redirect(base_url().'admin/menutags','refresh');
			}
			else
			{
				//set the flash data error message if there is one
				$data['messageadd'] = (validation_errors() ? validation_errors() : $this->session->flashdata('messageadd'));
			}
		}

		/*Edit Tag*/

		$data['message'] = $this->session->flashdata('message');
		if (isset($_POST['btnUpdatetag']) && !empty($_POST))
		{			
			$this->form_validation->set_rules('menuid1', 'menu', 'trim|required|xss_clean');			
			$this->form_validation->set_rules('catId1', 'category name', 'trim|required|xss_clean');	
			$this->form_validation->set_rules('tag_name', 'tag name', 'trim|required|xss_clean');	
			
			if ($this->form_validation->run() == true)
			{
				
				$menuid = $this->input->post('menuid1');				 
				$cat_id = $this->input->post('catId1');	 
				$tag_name = $this->input->post('tag_name');	 
				$about_tour = $this->input->post('about_tour');	 
				$editid = $this->input->post('tagid');	 

				$noof_duprec = $this->Common_model->noof_records("tagid","tbl_menutags","menuid ='$menuid' and cat_id='$cat_id' and tag_name = '$tag_name' and tagid!='$editid'");

				$noof_rec = $this->Common_model->noof_records("tagid","tbl_menutags","tagid='$editid'");
                if($noof_duprec < 1)
				{

				$update_data = array(
					'menuid'	    => $menuid,	
					'cat_id'	     => $cat_id,	
					'tag_name'	     => $tag_name,
					'about_tour'=> $about_tour,
				);	
				// print_r($update_data); exit;
				
				$querydb = $this->Common_model->update_records('tbl_menutags',$update_data,"tagid=$editid");
				if($querydb){
					$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Tag edited successfully.</div>');
				}
				else{
					$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Tag could not edited. Please try again.</div>');
				}
			}

			else
			{
				$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> You have already added tags to this menu and category</div>');
			
			}
				redirect(base_url().'admin/menutags','refresh');
			}
			else
			{
				//set the flash data error message if there is one
				$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
			}
		}

		$this->load->view('admin/manage_menutags',$data);
	}
	

	public function delete()
	{
		$delid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("tagid","tbl_menutags","tagid='$delid'");
		if($noof_rec>0)
		{
			$del = $this->Common_model->delete_records("tbl_menutags","tagid=$delid");
			if($del)
				$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Tag has been deleted successfully.</div>');
			else
				$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Tag could not deleted. Please try again.</div>');
		}
		redirect(base_url().'admin/menutags','refresh');
	}

	public function changestatus()
	{
		$stsid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("tagid","tbl_menutags","tagid='$stsid'");
		if($noof_rec>0)
		{
			$status = $this->Common_model->showname_fromid("status","tbl_menutags","tagid=$stsid");
			if($status==1)
				$updatedata = array('status' => 0);
			else
				$updatedata = array('status' => 1);
			$updatestatus = $this->Common_model->update_records("tbl_menutags",$updatedata,"tagid=$stsid");

			if($updatestatus)
				echo $status;
			else
				echo "error";
		}
		exit();
	}


	public function menutageditpopup()
	{
		$editid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("tagid","tbl_menutags","tagid='$editid'");
		if($noof_rec > 0)
		{
			$data = $this->Common_model->get_records("*","tbl_menutags","tagid='$editid'");
			foreach ($data as $rows)
			{	
			    $tagid = $rows['tagid'];
			    $menuid = $rows['menuid'];
			    $cat_id = $rows['cat_id'];
			    $tag_name = $rows['tag_name'];
			    $about_tour = $rows['about_tour'];
			}
	?>
        <div class="modal-header">
			<button type="button" class="close-btn " data-dismiss="modal">&times;</button>
			<h4 class="modal-title pupop-title">Edit Menu Tag</h4>
		</div>
		<div class="modal-body">
			<div class="modal-sub-body">
				<div class="row">
						<?php echo form_open(base_url('admin/menutags'), array( 'id' => 'form_editmenutags', 'name' => 'form_editmenutags', 'class' => 'col-md-12 modalform'));?>	

								<div class="col-md-6"> 
                                    <div class="form-group">
                                    <label> Menus </label>
                                    	<select class="form-control fld" name="menuid1" id="menuid1">
                                            <option value=""> -- Select menu tabs --</option>
                                           
                                             <?php  echo $this->Common_model->populate_select($dispid = $menuid, "menuid", "menu_name", "tbl_menus", "menuid != 1", "menu_name asc", ""); ?> 
                                           
                                           
                                           <!-- <option value="2" <?php //echo ($menuid == '2') ? 'selected="selected"' :''; ?> >  Getaways </option>
                                            <option value="3" <?php //echo ($menuid == '3') ? 'selected="selected"' :''; ?> >  Tours </option> -->

                                        </select>
                                    </div>
                                     <input type="hidden" name="tagid" id="tagid" value="<?php echo set_value('tagid',$tagid); ?>">
                                </div>
                                
		     					<div class="col-md-6"> 
                                    <div class="form-group">
                                        <label> Category </label>
                                       <select class="form-control fld" name="catId1" id="catId1"> 
                                           <?php  echo $this->Common_model->populate_select($dispid = $menuid, "catid", "cat_name", "tbl_menucateories", "menuid='$menuid'", "", ""); 
                                           ?>                                        
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6"> 
                                    <div class="form-group">
                                        <label> Tag </label>
                                       <input type="text" class="form-control fld" placeholder="Enter tags" name="tag_name" id="tag_name" value="<?php echo set_value('tag_name',$tag_name); ?>">  
                                    </div>
                                </div>

	                            <?php if($menuid =='3') { ?>
	                                <div id="abouttour2" class="col-md-6">
	                                    <div class="form-group">
	                                        <label> About tour package </label>                                       
	                                         <textarea cols=""  placeholder="About tour package" class="form-control textarea1" name="about_tour" id="about_tour"> <?php echo $about_tour ?></textarea>
	                                    </div>
	                                </div>
	                            <?php } else { ?>

	                            	 <div id="abouttour2" class="col-md-6" style="display: none;">
	                                    <div class="form-group">
	                                        <label> About tour package </label>                                       
	                                         <textarea cols=""  placeholder="About tour package" class="form-control textarea1" name="about_tour" id="about_tour"></textarea>
	                                    </div>
	                                </div>

	                            <?php } ?>

                                <div class="clearfix"></div>
								<div class="form-group">
									<label class="col-md-3"></label>
									<div class="reset-button col-md-9">
									  <button type="submit" class="btn redbtn btnUpdate" name="btnUpdatetag" id="btnUpdatetag">Update</button>
									</div>
								</div>

					<?php echo form_close(); ?>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
		<script type="text/javascript">
			     $(document).ready(function() {

                        $('#menuid1').on("change",function () {                   
                            var categoryId = $(this).find('option:selected').val();                            
                            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                                var dataJson = { [csrfName]: csrfHash, categoryId: categoryId};
                            $.ajax({
                                url: "<?php echo base_url() ?>admin/menutags/getcategory",
                                type: "POST",
                                data: dataJson,
                                success: function (response) {
                                    console.log(response);
                                   if(categoryId == '3') {
				                        $("#catId1").html(response);
				                        $("#abouttour2").show();
				                    } else {
				                        $("#catId1").html(response);
				                        $("#abouttour2").hide();
				                    }

                                },
                            });
                        }); 
                    });
		</script>
	<?php
		}
		exit();
	}



	public function getcategory()
	{			
		$categoryId=$_REQUEST['categoryId']; 
		if($categoryId > 0)
		{ 
			$selsubcategory_name = set_value('cat_id');				
			echo $this->Common_model->populate_select($selsubcategory_name,"catid","cat_name","tbl_menucateories","menuid='$categoryId'","");
			exit;
		} else { ?>
			<option value="0">-- Select Category --</option>
		<?php }
		exit();
	}
	
}



