<!DOCTYPE html>
<html lang="en">
    <head>
       <?php include("head.php"); ?>
       <link href="<?php echo base_url(); ?>assets/admin/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
    </head>
    <body class="hold-transition sidebar-mini">
        <div class="wrapper">
             <?php include("header.php"); ?>

            <?php include("sidemenu.php"); ?>

            <div class="content-wrapper">
                <section class="content-header">
                    <div class="header-icon">
                        <i class="fa fa-book"></i>
                    </div>
                    <div class="header-title">
                        <h1>Bookings</h1>
                        <small>Manage Bookings</small>
                    </div>
                </section>
                <!-- Main content -->
                <section class="content">
                    <div class="row">
						 <span id="ww"> </span>
                        <?php echo $message; ?>
                        <div class="col-sm-12">
                            <div class="panel panel-bd lobidrag">
                                <div class="panel-heading">
                                    <div class="btn-group" id="buttonexport">
                                        <h4><i class="fa fa-plus-circle"></i> Manage Bookings</h4>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table id="example" class="table table-bordered table-striped table-hover">
                                            <thead>
                                                <tr class="info">
                                                    <th width="6%">Sl #</th>
													<th width="12%">Invoice #</th>
                                                    <th width="16%">Package Name</th> 
                                                    <th width="12%">Customer</th>                  
													<th width="8%">Total Price</th>
													<th width="12%">Payment Status</th>													
													<th width="9%">Travel date</th>
                                                    <th width="9%">Invoice date</th>
													<th width="10%">Booking Status</th>
                                                    <th width="6%">Action</th>
                                                </tr>
                                            </thead>
                                           
                                            <tbody>
                                                <?php
                                                $cnt = isset($startfrom) ? $startfrom : 0;
                                                if (!empty($bookings)) { 
                                                    foreach ($bookings as $booking) {
                                                        $cnt++;
                                                        $booking_id = $booking['booking_id'];
														$booking_encid = $this->Common_model->encode($booking_id);
														$invoice_no = $booking['invoice_no'];
														$customer_id = $booking['customer_id'];
														
														$customer_name = '';
														$customer_phone = '';
														$customer_email = '';
															
														$customers = $this->Common_model->get_records("fullname, contact, email_id","tbl_customers","customer_id='$customer_id'");
														if(!empty($customers)){
    														foreach ($customers as $customer)
    														{
    															$customer_name = $customer['fullname'];
    															$customer_phone = $customer['contact'];
    															$customer_email = $customer['email_id'];
    														}
														}
														
														$package_id = $booking['package_id'];
														$package_name = $this->Common_model->showname_fromid("tpackage_name", "tbl_tourpackages", "tourpackageid ='$package_id'");
														$tpackage_url = $this->Common_model->showname_fromid("tpackage_url", "tbl_tourpackages", "tourpackageid ='$package_id'");
														
														$total_price = $booking['total_price'];
														$payment_status = $booking['payment_status'];
														$payment_percentage = $booking['payment_percentage'];
														$paid_amount = $booking['paid_amount'];
														$total_price = $booking['total_price'];
														
														$date_of_travel = $booking['date_of_travel'];
														$booking_date = $booking['booking_date'];
														$booking_status = $booking['booking_status'];
                                                ?>
                                                        <tr>
                                                            <td><?php echo $cnt; ?></td>
															<td><a href="<?php echo base_url()."invoice/".$invoice_no."/".$booking_encid ?>" target="_blank"><?php echo $invoice_no; ?></a></td>
                                                            <td><a href="<?php echo base_url().'packages/'.$tpackage_url; ?>" target="_blank"><?php echo $package_name; ?></a></td>  
                                                            <td><?php echo $customer_name."<br>".$customer_email."<br>".$customer_phone; ?></td>
															<td><?php echo $this->Common_model->currency.$total_price; ?></td>
															<td>
																<?php 
																	if($payment_status == 1)
																	{ 
																		echo "PAID<br>".$this->Common_model->currency.$paid_amount." ( ".$payment_percentage."% )"; 
																	}
																	else
																	{
																		echo "NOT PAID<br>".$this->Common_model->currency.$paid_amount." ( ".$payment_percentage."% )"; 
																	}
																?>	
															</td>
															<td><?php echo $this->Common_model->dateformat($date_of_travel); ?></td>
															<td><?php echo $this->Common_model->dateformat($booking_date); ?></td>
															<td>
																<?php 
																	if($booking_status == 1)
																		echo "Approved"; 
																	else if($booking_status == 2)
																		echo "Cancelled"; 
																	else
																		echo "Pending";
																?>	
															</td>
                                                            <td>                                                                
                                                                <a href="<?php echo base_url().'admin/bookings/view/'.$booking_id; ?>" class="btn btn-primary btn-sm view" title="View"><i class="fa fa-eye"></i></a>

                                                                <a onClick="return confirm('Are you sure to delete this booking?')" href="<?php echo base_url().'admin/bookings/delete/'.$booking_id; ?>"  class="btn btn-danger btn-sm" title="Delete"><i class="fa fa-trash-o"></i> </a> 
                                                            </td>
                                                        </tr>
												<?php
														}
													} 
													else {
												?>
                                                    <tr>
                                                        <td class="text-center" colspan="7"> No data available in table </td>
                                                    </tr>
                                                <?php } ?>
                                                                                             
                                            </tbody>
                                        </table>
                                       
                                    </div>
                                </div>                          
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <div id="myModal" class="modal fade" role="dialog">
                <div class="modal-dialog modal-lg">
                    <!-- Modal content-->
                    <div class="modal-content"> </div>
                </div>
            </div>

            <?php include("footer.php"); ?>
        
        <script type="text/javascript">
            $(document).on('click', '.status', function(){
                if(confirm('Are you sure to change the status?'))
                {
                    var val = $(this).data("id");
                    var valsplit = val.split("-");
                    var id = valsplit[1];
                    jQuery('[data-id='+val+']').after('<div class="spinner" style="text-align:center;color:#377b9e;"><i class="fa fa-spinner fa-spin fa-1x"></i></div>');
    
                    $.ajax({
                        url: "<?php echo base_url(); ?>admin/itinerary/changestatus/"+id,
                        type: 'post',
                        data: {'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'},
                        cache: false,
                        success: function (data) {
                            //alert(data);
                            jQuery('.spinner').remove();                        
                            if(data == '1') //Inactive
                            {
                                jQuery('[data-id='+val+']').html('<a href="javascript:void(0)" title="Status is inactive. Click here to make it active."><span class="label-custom label label-danger">Inactive</span></a>');
                            }
                            else if(data == '0') //Active
                            {
                                jQuery('[data-id='+val+']').html('<a href="javascript:void(0)" title="Status is active. Click here to make it inactive."><span class="label-custom label label-success">Active</span></a>');
                            }
                            else
                            {
                                alert("Sorry! Unable to change status.");
                            }
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
                        }
                    });
                }
            });
      
      
       /* Featured*/
			
			$(document).on('click', '.unfeatured', function() {   
				var tid = $(this).data("id");
				if(confirm("Are you sure, you want to unfeature this package?")) { 
				$.ajax({
					url: "<?php echo base_url(); ?>admin/itinerary/mark_as_unfeatured",
					type: 'post',   
					data: {'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>',tid : tid},   
					success: function (data) {
						$("#ww").html(data);  
						location.reload();
					},
					error: function (XMLHttpRequest, textStatus, errorThrown) {
						alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
					}
				});
			  }
			});
			
			 /* Unfeatured*/
			
			$(document).on('click', '.featured', function() {   
				var tid = $(this).data("id");
				if(confirm("Are you sure, you want to feature this package?")) { 
				$.ajax({
					url: "<?php echo base_url(); ?>admin/itinerary/mark_as_featured",
					type: 'post',   
					data: {'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>',tid : tid},   
					success: function (data) {
						$("#ww").html(data);  
						location.reload();
					},
					error: function (XMLHttpRequest, textStatus, errorThrown) {
						alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
					}
				});
			  }
			});




            $(document).ready(function () {
                $('#example').DataTable();
            });
        </script>
        
    </body>
</html>

