<!DOCTYPE html>
<html lang="en">
    <head>
       <?php include("head.php"); ?>
       <link href="<?php echo base_url(); ?>assets/admin/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
    </head>
    <body class="hold-transition sidebar-mini">
        <div class="wrapper">
             <?php include("header.php"); ?>

            <?php include("sidemenu.php"); ?>

            <div class="content-wrapper">
                <section class="content-header">
                    <div class="header-icon">
                        <i class="fa fa-globe"></i>
                    </div>
                    <div class="header-title">
                        <h1>Tour Packages</h1>
                        <small>Manage tour packages</small>
                    </div>
                </section>
                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <?php echo $message; ?>
                        <span id="ww"> </span>
                        <div class="col-sm-12">
                            <div class="panel panel-bd lobidrag">
                                <div class="panel-heading">
                                    <div class="btn-group" id="buttonexport">
                                        <a href="<?php echo base_url(); ?>admin/tour-packages/add">
                                            <h4><i class="fa fa-plus-circle"></i> Add Tour Package</h4>
                                        </a> 
									</div>
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table id="example" class="table table-bordered table-striped table-hover">
                                            <thead>
                                                <tr class="info">
                                                    <th width="6%">Sl #</th>
                                                    <th width="13%">Packages</th>
                                                    <th width="10%">Starting City</th>
                                                    <th width="10%">Package Durations</th>
													<th width="9%">Price (<?php echo $this->Common_model->currency; ?>)</th>
													<th width="13%">Itinerary</th>
                                                    <th width="12%">Banner Images</th>                                                   
													<th width="12%">Tour Images</th>
                                                    <th width="6%">Status</th>
                                                    <th width="9%">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
												$cnt = 0;
												if( !empty($row) )
												{
													foreach ($row as $rows)
													{
														$cnt++;
														$tourpackageid = $rows['tourpackageid'];
														$tpackage_name = $rows['tpackage_name'];
														$tour_price = $rows['price'];
														$tpackage_image = $rows['tpackage_image'];
														$tour_thumb = $rows['tour_thumb'];
														$status = $rows['status'];
														$tpackage_url = $rows['tpackage_url'];
														
														$package_duration = $rows['package_duration'];														
													    $package_durationnew = $this->Common_model->showname_fromid("duration_name","tbl_package_duration","durationid=$package_duration");
														
														$package_itinerary = $rows['itinerary'];													
													    $package_itinerary_name = $this->Common_model->showname_fromid("itinerary_name","tbl_itinerary","itinerary_id=$package_itinerary");
														
														$package_starting_city = $rows['starting_city'];													
													    $package_starting_city_name = $this->Common_model->showname_fromid("destination_name","tbl_destination","destination_id=$package_starting_city");
														
														$en_admin = $this->Common_model->encode("admin");
												?>
										
                                                <tr>
                                                    <td><?php echo $cnt; ?></td>
													<td><a href="<?php echo base_url().'packages/'.$tpackage_url.'/?preview='.$en_admin; ?>" target="_blank"><?php echo $tpackage_name; ?> (<?php echo $rows['tpackage_code']; ?>)</a></td>
													<td><?php echo $package_starting_city_name; ?></td>
													<td><?php echo $package_durationnew; ?></td>
													<td><?php echo $tour_price; ?></td>
													<td><a href="<?php echo base_url().'admin/itinerary/view/'.$package_itinerary; ?>" target="_blank"><?php echo $package_itinerary_name; ?></a></td>
													<td>
														<?php
															if(file_exists("./uploads/".$tpackage_image) && ($tpackage_image!=''))
															{ 
																echo '<a href="'.base_url().'uploads/'.$tpackage_image.'" target="_blank"><img src="'.base_url().'uploads/'.$tpackage_image.'" style="width:90px;" alt="image" /></a>';
															}
														?>
													</td>

													<td>
														<?php
															if(file_exists("./uploads/".$tour_thumb) && ($tour_thumb!=''))
															{ 
																echo '<a href="'.base_url().'uploads/'.$tour_thumb.'" target="_blank"><img src="'.base_url().'uploads/'.$tour_thumb.'" style="width:90px;" alt="image" /></a>';
															}
														?>
													</td>

                                                    <td>                                        
														<?php if($status==1) { ?>
															<span class="status" data-id="<?php echo "status-".$tourpackageid; ?>"><a href="javascript:void(0)" title="Status is active. Click here to make it inactive."><span class="label-custom label label-success">Active</span></a></span>
														<?php } else { ?>
															<span class="status" data-id="<?php echo "status-".$tourpackageid; ?>"><a href="javascript:void(0)" title="Status is inactive. Click here to make it active."><span class="label-custom label label-danger">Inactive</span></a></span>
														<?php } ?>
													</td>
                                                    <td>
														<a href="<?php echo base_url().'admin/tour_packages/edit/'.$tourpackageid; ?>" class="btn btn-success btn-sm view1 tbl-icon-btm" title="Edit"> <i class="fa fa-pencil"></i></a>
														
														<a href="<?php echo base_url().'admin/tour_packages/view/'.$tourpackageid; ?>" class="btn btn-primary btn-sm" title="View"><i class="fa fa-eye"></i></a>
														
														<a onClick="return confirm('Are you sure to delete this package?')" href="<?php echo base_url().'admin/tour_packages/delete/'.$tourpackageid; ?>" class="btn btn-danger btn-sm" title="Delete"><i class="fa fa-trash-o"></i> </a>
														
														
													<!--	<?php // if($is_featured ==1) { ?>
															<a href="javascript:void(0)" data-id="<?php //echo $tourpackageid; ?>" title="Package is featured. Click here to make it unfeatured." class="btn btn-warning btn-sm unfeatured"><i class="fa fa-asterisk"></i> </a>
														<?php //} else { ?>
															<a href="javascript:void(0)" data-id="<?php // echo $tourpackageid; ?>" title="Package is unfeatured. Click here to make it featured." class="btn btn-default btn-sm featured"><i class="fa fa-asterisk "></i></a>
														<?php //} ?> -->
														
													</td>
                                                </tr>

                                                <?php
                                        
													}
												}
												else
												{
												?>
												<tr>
													<td class="text-center" colspan="6"> No data available in table </td>
												</tr>
												<?php
												}
												?>                                                
                                            </tbody>
                                        </table>
                                       
                                    </div>
                                </div>                          
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <div id="myModal" class="modal fade" role="dialog">
                <div class="modal-dialog modal-lg">
                    <!-- Modal content-->
                    <div class="modal-content"> </div>
                </div>
            </div>

            <?php include("footer.php"); ?>
        

		<script type="text/javascript">
			$(document).on('click', '.view', function(){
				jQuery('#myModal .modal-content').html('<div style="text-align:center;margin-top:150px;margin-bottom:100px;color:#377b9e;"><i class="fa fa-spinner fa-spin fa-3x"></i> <span>Processing...</span></div>');
				var val = $(this).data("id");				
				$.ajax({
					url: "<?php echo base_url(); ?>admin/tour_packages/view_pop/"+val,
					type: 'post',
					data: {'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'},
					cache: false,					
					//processData: false,
					success: function (modal_content) {
						jQuery('#myModal .modal-content').html(modal_content);
						// LOADING THE AJAX MODAL
						$('#myModal').modal('show');
					},
					error: function (XMLHttpRequest, textStatus, errorThrown) {
						alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
						$('#errMessage').html('<div class="errormsg"><i class="fa fa-times"></i> Your query could not executed. Please try again.</div>');
					}
				});
			});
			
		   $(document).on('click', '.status', function(){
				if(confirm('Are you sure to change the status?'))
				{
					var val = $(this).data("id");
					var valsplit = val.split("-");
					var id = valsplit[1];
					$('[data-id='+val+']').after('<div class="spinner" style="text-align:center;color:#377b9e;"><i class="fa fa-spinner fa-spin fa-1x"></i></div>');
					$.ajax({
						url: "<?php echo base_url(); ?>admin/tour_packages/changestatus/"+id,
						type: 'post',
						data: {'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'},
						cache: false,
						success: function (data) {
							$('.spinner').remove();                        
							if(data == '1') //Inactive
							{                                
								$('[data-id='+val+']').html('<a href="javascript:void(0)" title="Status is inactive. Click here to make it active."><span class="label-custom label label-danger">Inactive</span></a>');
							}
							else if(data == '0') //Active
							{
								$('[data-id='+val+']').html('<a href="javascript:void(0)" title="Status is active. Click here to make it inactive."><span class="label-custom label label-success">Active</span></a>');
							}
							else
							{
								alert("Sorry! Unable to change status.");
							}
						},
						error: function (XMLHttpRequest, textStatus, errorThrown) {
							alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
						}
					});
}
		   });
		   
		   
		   
		   /* Featured
			
			$(document).on('click', '.unfeatured', function() {   
				var tid = $(this).data("id");
				if(confirm("Are you sure, you want to unfeature this package?")) { 
				$.ajax({
					url: "<?php echo base_url(); ?>admin/tour_packages/mark_as_unfeatured",
					type: 'post',   
					data: {'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>',tid : tid},   
					success: function (data) {
						$("#ww").html(data);  
						location.reload();
					},
					error: function (XMLHttpRequest, textStatus, errorThrown) {
						alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
					}
				});
			  }
			});
			
			//Unfeatured
			
			$(document).on('click', '.featured', function() {   
				var tid = $(this).data("id");
				if(confirm("Are you sure, you want to feature this package?")) { 
				$.ajax({
					url: "<?php echo base_url(); ?>admin/tour_packages/mark_as_featured",
					type: 'post',   
					data: {'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>',tid : tid},   
					success: function (data) {
						$("#ww").html(data);  
						location.reload();
					},
					error: function (XMLHttpRequest, textStatus, errorThrown) {
						alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
					}
				});
			  }
			});*/


		
			$(document).ready(function () {
				$('#example').DataTable();
			});
		</script>
		
    </body>
</html>

