<!doctype html>
<html>

<head>
    <?php include("head.php"); ?>
</head>

<body>
    <?php include("header.php"); ?>

        <section>
            <img src="<?php echo base_url(); ?>assets/images/getaways.jpg" class="img-fluid">
		        </section>
        <section class="mt80 mb100">
            <div class="container">
                <div class="row">
                    <div class="col-xl-4 co-lg-4">
                        <div class="getway-sec">
                            <h5>Popular Getaways</h5>

                            <nav class="leftsidemenulist mb-4">

                                <ul>
                                    <li><a href="#profile">Best hill stations around Bangalore</a></li>
                                    <li><a href="#message">Best waterfalls near Bangalore</a></li>
                                    <li><a href="#message">Adventure / Trekking near Bangalore</a></li>
                                    <li><a href="#message">Best beaches around Bangalore</a></li>
                                    <li><a href="#message">Heritage sites near Bangalore</a></li>
                                </ul>
                            </nav>

                            <h5>Most Popular Packages</h5>

                            <div class="packlist mb-4">

                                <ul>
                                    <li><a href="#">Coorg Tour Packages</a>
											<span>Ex-Delhi</span>
											<div style="float: right;">
											<span class="packageCostOrig" style="text-decoration: line-through; color: #A0A0A0; font-size:14px" ;>₹ 6100</span>
                                    <span class="packageCost">₹4850</span>
									</div>									
									</li>
									
									<li><a href="#">Ooty Tour Packages</a>
											<span>Ex-Kochi</span>
											<div style="float: right;">
											<span class="packageCostOrig" style="text-decoration: line-through; color: #A0A0A0; font-size:14px" ;>₹ 6100</span>
                                    <span class="packageCost">₹4850</span>
									</div>									
									</li>
									<li><a href="#">Wayanad Tour Packages</a>
											<span>Ex-Bangalore</span>
											<div style="float: right;">
											<span class="packageCostOrig" style="text-decoration: line-through; color: #A0A0A0; font-size:14px" ;>₹ 6100</span>
                                    <span class="packageCost">₹4850</span>
									</div>									
									</li>
									<li><a href="#">Munnar Tour Packages</a>
											<span>Ex-Kerala</span>
											<div style="float: right;">
											<span class="packageCostOrig" style="text-decoration: line-through; color: #A0A0A0; font-size:14px" ;>₹ 6100</span>
                                    <span class="packageCost">₹4850</span>
									</div>									
									</li>
                                   

                                </ul>
                           

                            <div class="rightbookingbox">

                                <h3>Get our assistance for easy booking</h3>
                                <span class="cullusbtn">Want us to call you?</span>
                                <p>Call us at (Toll Free No.)</p>
                                <h5>(+01)-800-346-6277</h5>
                            </div>
							
							 </div>

                        </div>
                    </div>

                    <div class="col-xl-8 col-lg-8">
<h4 class="mb-2 bluefont">Lonavala Overview</h4>
                        <div class="getwaybg">
						
                            <div class="row">
                                <div class="col-xl-12 col-lg-12">
                                    <h4 class="mb-2 bluefont"> Coorg </h4>
                                </div>
                                <div class=" col-xl-4 col-lg-4">
                                    <div class="get-image">
                                        <img src="<?php echo base_url(); ?>assets/images/coorg.jpg" class="img-fluid">
                                    </div>
                                </div>
                                <div class=" col-xl-8 col-lg-8">
                                    <div class="getwaycontent">
                                      <div class="tag-list">
									  <ul>
									  <li> <i class="fas fa-tags"></i> Hill Station </li>
									  <li> Lake & Backwater </li>
										<li>  Wildlife</li>
									  </ul>
									  </div>
                                        <p>At a distance of 265 km from Bangalore, 117 km from Mysore, 132 km from Mangalore, 322 km from Coimbatore & 362 km from Kochi, Coorg or Kodagu is a district in Karnataka and Madikeri is the district headquarters. At an altitude of 1525 meters on Western Ghats, it is also known as the Scotland of India. Coorg is the most famous places to visit in India and among popular 2 day trip near Bangalore. It is also one of the top destinations of Karnataka tourism.
                                                                                   </p>
									
										<ul class="btn-innersec">
										<li class="v-btn"><a href="#">Overview</a> </li>
										<li class="visit-btn"><a href="#">Places to Visit</a> </li>
										<li class="package-btnnew"><a href="#">Packages from Rs. 5100 </a> </li>
										
										</ul>
										
										</div>
                                    </div>
                                </div>
								
								<hr>
								    <div class="row">
                                <div class="col-xl-12 col-lg-12">
                                    <h4 class="mb-2 bluefont"> Coorg </h4>
                                </div>
                                <div class=" col-xl-4 col-lg-4">
                                    <div class="get-image">
                                        <img src="<?php echo base_url(); ?>assets/images/coorg.jpg" class="img-fluid">
                                    </div>
                                </div>
                                <div class=" col-xl-8 col-lg-8">
                                    <div class="getwaycontent">
                                      <div class="tag-list">
									  <ul>
									  <li> <i class="fas fa-tags"></i> Hill Station </li>
									  <li> Lake & Backwater </li>
										<li>  Wildlife</li>
									  </ul>
									  </div>
                                        <p>At a distance of 265 km from Bangalore, 117 km from Mysore, 132 km from Mangalore, 322 km from Coimbatore & 362 km from Kochi, Coorg or Kodagu is a district in Karnataka and Madikeri is the district headquarters. At an altitude of 1525 meters on Western Ghats, it is also known as the Scotland of India. Coorg is the most famous places to visit in India and among popular 2 day trip near Bangalore. It is also one of the top destinations of Karnataka tourism.
                                                                                   </p>
									
										<ul class="btn-innersec">
										<li class="v-btn"><a href="#">Overview</a> </li>
										<li class="visit-btn"><a href="#">Places to Visit</a> </li>
										<li class="package-btnnew"><a href="#">Packages from Rs. 5100 </a> </li>
										
										</ul>
										
										</div>
                                    </div>
                                </div>
								<hr>
								
								    <div class="row">
                                <div class="col-xl-12 col-lg-12">
                                    <h4 class="mb-2 bluefont"> Coorg </h4>
                                </div>
                                <div class=" col-xl-4 col-lg-4">
                                    <div class="get-image">
                                        <img src="<?php echo base_url(); ?>assets/images/coorg.jpg" class="img-fluid">
                                    </div>
                                </div>
                                <div class=" col-xl-8 col-lg-8">
                                    <div class="getwaycontent">
                                      <div class="tag-list">
									  <ul>
									  <li> <i class="fas fa-tags"></i> Hill Station </li>
									  <li> Lake & Backwater </li>
										<li>  Wildlife</li>
									  </ul>
									  </div>
                                        <p>At a distance of 265 km from Bangalore, 117 km from Mysore, 132 km from Mangalore, 322 km from Coimbatore & 362 km from Kochi, Coorg or Kodagu is a district in Karnataka and Madikeri is the district headquarters. At an altitude of 1525 meters on Western Ghats, it is also known as the Scotland of India. Coorg is the most famous places to visit in India and among popular 2 day trip near Bangalore. It is also one of the top destinations of Karnataka tourism.
                                                                                   </p>
									
										<ul class="btn-innersec">
										<li class="v-btn"><a href="#">Overview</a> </li>
										<li class="visit-btn"><a href="#">Places to Visit</a> </li>
										<li class="package-btnnew"><a href="#">Packages from Rs. 5100 </a> </li>
										
										</ul>
										
										</div>
                                    </div>
                                </div>
								
								
                            </div>
							
							
                        </div>

                    </div>

                </div>
            </div>
        </section>

        <div class="modal fade" id="bookingmodal">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Our Booking Policy</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="policyterms">
                            <ul>
                                <li>Booking can be modified up to 3 days before the travel date (cancellation / amendment charges apply for hotels along with any price difference for revised date - hotels based on availability)</li>
                                <li>Booking can be cancelled up to 3 days before travel date (below Cancellation Policy applies - no partial cancellation)</li>
                                <li>Itinerary can be changed by adding / removing places (as long as the schedule is not impacted) up to 3 days before the travel date. Any extra kilo-meters added due to itinerary change is payable directly to the cab driver.</li>
                                <li>Vehicle can be upgraded to the next category by paying the fare difference up to 3 days before the travel date</li>
                                <li>For multi-day trips, free pick-up &amp; drop from your location within city limits (Ex: BBMP limits for Bengaluru, GHMC limits for Hyderabad, etc). All one day trips start from city center (Ex: Majestic for Bangalore).</li>
                                <li>Standard Hotel check-in time is usually between 12 PM - 2 PM &amp; check-out time is between 10 AM to 12 PM. Early check-in is subject to availability &amp; hotel may charge extra (not included in the tour price). In case of late check-in, please inform the hotel about your arrival time.</li>
                                <li>In case you arrive before check-in time &amp; free rooms are unavailable, you can fresh-up in hotel washroom and proceed with sightseeing until your check-in time.</li>
                                <li>Customers should be ready for sightseeing at Start Time mentioned in the itinerary in order to cover all the places in itinerary. Sightseeing can't extend beyond 7 PM and any places missed can't be covered on following day.</li>
                                <li>Sightseeing is limited to the places mentioned in the itinerary. If time permits, you may visit additional places (not mentioned in itinerary) by paying for extra kilo-meters to the cab driver.</li>
                                <li>In case of natural disasters or cab strike, your tour may be cancelled by Trawell.in and 100% of your booking amount will be refunded</li>
                                <li>In extreme cases, your tour may be cancelled by Trawell.in for unavoidable reasons (within 24 hours of booking) and 100% of your booking amount will be refunded</li>
                                <li>In rare cases, the primary hotel mentioned in the tour page may be unavailable. You will be offered alternate accommodation in the same or higher category. If you are not satisfied with alternate hotel, you may choose to cancel the tour (100% of booking amount will be refunded).</li>
                                <li>Hotel rooms are provided on twin sharing basis. In case of 3 adults or child above 5 years, 3-sharing room or Room with extra bed/mattress will be provided</li>
                                <li>Wherever room category is not mentioned in the quote / website, Base category room will be provided</li>
                                <li>Hotel may deny check-in for unmarried couple and no refund will be issued in such cases</li>
                                <li>Please check weekly off days for sightseeing places. Also, few places may be closed due to heavy rains / maintenance without prior intimation &amp; we have no control on such incidents. Wherever possible, alternate sightseeing may be arranged in such cases.</li>
                                <li>Entry Fees &amp; Activity Fees may change without any intimation and we have no control on the same. All fees mentioned in our website are for Indian nationals.</li>
                                <li>Any special requests like English/Hindi driver is based on availability and can't be guaranteed</li>
                                <li>Refund for cancelled tours usually takes around 7-10 business days</li>
                                <li>Additional charges may apply for Airport Pick-up/Drop (select Airport Pickup option from Additional Options popup on Tour Page)</li>
                                <li>Any issues encountered during the trip need to be resolved with Tour Manager immediately during the trip. Issues can't be addressed after completion of the trip.</li>
                                <li>Trawell.in liability is limited to providing cab &amp; hotel. Sightseeing is complementary and it carries no liability. While we try our best to cover all places in the itinerary, no refund will be issued for sightseeing missed during the trip.</li>
                                <li>Any service issues related to Vehicle &amp; Accommodation need to be resolved with the service provider directly, while Trawell.in can help facilitate the communication</li>
                                <li>Vehicles Provided (all vehicles are A/C only) : Hatchback - Indica V2, Swift, Ritz, similar; Sedan - Dzire, Etios, Fiesta, Xcent, Amaze, similar; SUV - Innova, Xylo, or similar</li>
                                <li>Hotel Voucher will be shared within 2 working hours from the time of booking</li>
                                <li>All Hotels are booked in the name of Primary Traveler mentioned at the time of booking. Any change in guest name is considered as tour canceled and rebooked - cancellation charges apply &amp; hotels based on availability. Valid ID &amp; Address proof need to be carried for all guests including children.</li>
                                <li>On Christmas (Dec 25th) &amp; New Year (Dec 31st), Hotel may charge extra amount for Mandatory gala night dinner from guests (directly payable at hotel - not included in the package cost)</li>
                                <li>If hotel does not provide complimentary breakfast, INR 100 for 2-star, INR 150 for 3-star &amp; INR 250 for 4-star will be provided as Breakfast expenses per person (above 5 years). If you miss complimentary breakfast in the hotel due to early morning sightseeing (before 8 AM), you need to have breakfast outside at own expense.</li>
                                <li>Cab &amp; Driver details will be provided 10 hours before the Trip Start Time</li>
                                <li>In case the cab arrival is delayed on Day 1, you can extend the trip end time on last day up to the duration the cab pickup is delayed</li>
                                <li>In case of vehicle breakdown and issue is not resolved in 2 hours (from the time the issue is reported), we will provide alternate vehicle (or) free accommodation in nearby town with food allowance until the issue is resolved.</li>
                                <li>Usually Hotels don't charge for below 3 years kids, no need to select kids below 3 years while boooking tour. In case of any charges by hotels for below 3y kids, amount needs to be paid directly at the hotel.</li>
                                <li>Refund is issued only in case hotel denies check-in and customer had to book own stay or vehicle could not be provided and customer arranges own transport.</li>
                                <li>If tour is booked with partial advance payment, additional terms can be found here</li>
                                <li>For cab only bookings, additional terms can be found here</li>
                                <li>Below Cancellation Policy is applicable for all tours irrespective of date of booking and mode of booking:</li>
                                <li>Cancellation Policy (Domestic Tours Except Andamans &amp; North East):</li>
                                <li>16 days &amp; beyond from date of travel (excluding travel date) - 15% of Order Total is charged as cancellation fee</li>
                                <li>Between 8-15 days from date of travel (excluding travel date) - 50% of Order Total is charged as cancellation fee</li>
                                <li>Between 3-7 days from date of travel (excluding travel date) - 75% of Order Total is charged as cancellation fee</li>
                                <li>No Refund if cancelled within 2 days from date of travel, excluding travel date (sorry, we already paid for your Hotel &amp; Cab by this time)</li>
                                <li>Cancellation Policy (International Tours, Andamans &amp; North East):</li>
                                <li>16 days &amp; beyond from date of travel (excluding travel date) - 50% of Order Total is charged as cancellation fee</li>
                                <li>Between 8-15 days from date of travel (excluding travel date) - 75% of Order Total is charged as cancellation fee</li>
                                <li>No Refund if cancelled within 7 days from date of travel, excluding travel date (sorry, we already paid for your Hotel &amp; Cab by this time)</li>
                            </ul>
                        </div>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>

                </div>
            </div>
        </div>

        <?php include("footer.php"); ?>
            <script>
                $(document).ready(function() {
                    $("#myModal ").modal('show');
                });
            </script>
</body>

</html>