<?php
$first_segment = $this->uri->segment(1);
$seco_segment = $this->uri->segment(2);
$thrd_segment = $this->uri->segment(3);


$getSeoMetaTags = $this->Common_model->get_records("par_value", "tbl_parameters", "parid in (25, 26, 27)", "parid asc");
$meta_title = $getSeoMetaTags[0]['par_value'];
$meta_description = $getSeoMetaTags[1]['par_value'];
$meta_keywords = $getSeoMetaTags[2]['par_value'];

if (($first_segment == "") || ($first_segment == 'home') || ($first_segment == 'contactus') || ($first_segment == 'about') || ($first_segment == 'blog') || ($first_segment == 'review') || ($first_segment == 'faq') || ($first_segment == 'hiring') || ($first_segment == 'travel-agent') || ($first_segment == 'advertise') || ($first_segment == 'destinations') || ($first_segment == 'tour-packages') || ($first_segment == 'getaway') || ($first_segment == 'itineraries')) {
    
    if (($first_segment == "") || ($first_segment == 'home')) {
        $seowhere = "content_id=1";
    } else if ($first_segment == 'contactus') {
        $seowhere = "content_id=3";
    } else if ($first_segment == 'about') {
        $seowhere = "content_id=4";
    } else if ($first_segment == 'blog') {
        $seowhere = "content_id=5";
    } else if ($first_segment == 'faq') {
        $seowhere = "content_id=6";
    } else if ($first_segment == 'review') {
        $seowhere = "content_id=7";
    } else if ($first_segment == 'hiring') {
        $seowhere = "content_id=8";
    } else if ($first_segment == 'travel-agent') {
        $seowhere = "content_id=9";
    } else if ($first_segment == 'advertise') {
        $seowhere = "content_id=10";
    } else if ($first_segment == 'destinations') {
        $seowhere = "content_id=11";
    } else if ($first_segment == 'tour-packages') {
        $seowhere = "content_id=12";
    } else if ($first_segment == 'getaway') {
        $seowhere = "content_id=13";
    } else if ($first_segment == 'itineraries') {
        $seowhere = "content_id=14";
    } 
    
    $getseo_findrec = $this->Common_model->get_records("seo_title, seo_description, seo_keywords", "tbl_contents", "$seowhere", "");
    
    if(!empty($getseo_findrec)){
        foreach ($getseo_findrec as $rowseo_rec) {
            $title = $rowseo_rec['seo_title'];
            $description = $rowseo_rec['seo_description'];
            $keywords = $rowseo_rec['seo_keywords'];
        }
    }
    $meta_title = ($title != "") ? $title : $meta_title;
     if ($first_segment == 'blog' && isset($blog_title)) {
        $meta_title =$blog_title;
    }     
    
    $meta_description = ($description != "") ? $description : $meta_description;
    $meta_keywords = ($keywords != "") ? $keywords : $meta_keywords;
    
}   else if (($first_segment == 'tours') || ($first_segment == 'getaways')) {
    $tag_url = $this->uri->segment(3); 
    $getTagSeos = $this->Common_model->get_records("meta_title,meta_keywords,meta_description", "tbl_menutags", "tag_url ='$tag_url'", "", "1");
	if(!empty($getTagSeos)){
		foreach ($getTagSeos as $getTagSeos) {
			$title = $getTagSeos['meta_title'];
			$description = $getTagSeos['meta_description'];
			$keywords = $getTagSeos['meta_keywords'];
		}
	
        $meta_title = ($title != "") ? $title : $meta_title;
        $meta_description = ($description != "") ? $description : $meta_description;
        $meta_keywords = ($keywords != "") ? $keywords : $meta_keywords;
	}
}   else if ($first_segment == 'packages') {  
    $pack_url = $this->uri->segment(2);  
    $gettourseos = $this->Common_model->get_records("meta_title,meta_keywords,meta_description", "tbl_tourpackages", "tpackage_url ='$pack_url'", "", "1");
    if(!empty($gettourseos)){
		foreach ($gettourseos as $gettourseo) {
			$title = $gettourseo['meta_title'];
			$description = $gettourseo['meta_description'];
			$keywords = $gettourseo['meta_keywords'];
		}
	
        $meta_title = ($title != "") ? $title : $meta_title;
        $meta_description = ($description != "") ? $description : $meta_description;
        $meta_keywords = ($keywords != "") ? $keywords : $meta_keywords;
    }
}   else if (($first_segment == 'destination') || ($first_segment == 'destination-package') || ($first_segment == 'places-to-visit')) {  
    if($first_segment == 'destination-package') {
            $dest_url = $this->uri->segment(2);  
    } else {
            $dest_url = $this->uri->segment(3);  
    }

    $getdestseos = $this->Common_model->get_records("meta_title,meta_keywords,meta_description", "tbl_destination", "destination_url ='$dest_url'", "", "1");
    if(!empty($getdestseos)){
        foreach ($getdestseos as $getdestseo) {
            $title = $getdestseo['meta_title'];
            $description = $getdestseo['meta_description'];
            $keywords = $getdestseo['meta_keywords'];
        }
        
        $meta_title = ($title != "") ? $title : $meta_title;
        $meta_description = ($description != "") ? $description : $meta_description;
        $meta_keywords = ($keywords != "") ? $keywords : $meta_keywords;
    }
    
}   else if ( ($first_segment == 'place') || ($first_segment == 'place-package') ) {  
		
    if($first_segment == 'place'){
            $dest_url = $this->uri->segment(4);  
    } else {
            $dest_url = $this->uri->segment(2);  
    }
    $place_url = $this->uri->segment(4);  
    $getPLaceseos = $this->Common_model->get_records("meta_title,meta_keywords,meta_description", "tbl_places", "place_url ='$place_url'", "", "1");
    if(!empty($getPLaceseos)){
        foreach ($getPLaceseos as $getPLaceseo) {
            $title       = $getPLaceseo['meta_title'];
            $description = $getPLaceseo['meta_description'];
            $keywords    = $getPLaceseo['meta_keywords'];
        }
        
        $meta_title = ($title != "") ? $title : $meta_title;
        $meta_description = ($description != "") ? $description : $meta_description;
        $meta_keywords = ($keywords != "") ? $keywords : $meta_keywords;
    }
    
}	else if ($first_segment == 'itinerary') {
    $itinerary_url = $this->uri->segment(2);  
    $getItineraryseos = $this->Common_model->get_records("meta_title,meta_keywords,meta_description", "tbl_itinerary", "itinerary_url ='$itinerary_url'", "", "1");
    if(!empty($getItineraryseos)){
        foreach ($getItineraryseos as $getItineraryseo) {
            $title       = $getItineraryseo['meta_title'];
            $description = $getItineraryseo['meta_description'];
            $keywords    = $getItineraryseo['meta_keywords'];
        }
        
        $meta_title = ($title != "") ? $title : $meta_title;
        $meta_description = ($description != "") ? $description : $meta_description;
        $meta_keywords = ($keywords != "") ? $keywords : $meta_keywords;
    }
    
}	else {
    $meta_title = $meta_title;
    $meta_description = $meta_description;
    $meta_keywords = $meta_keywords;
}

?>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">  
              
        <title> <?php echo $meta_title; ?>   </title>
		<meta name="description" content="<?php echo $meta_description; ?>">
		<meta name="keywords" content="<?php echo $meta_keywords; ?>"> 

        <link rel="icon" href="<?php echo base_url(); ?>assets/admin/img/fav-icon.png" sizes="16x16" type="image/png">
        <link href="https://fonts.googleapis.com/css?family=Encode+Sans+Semi+Condensed|Questrial&display=swap" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/css/fontawesome-all.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/animate.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/Pe-icon-7-stroke.css">
        <link href="<?php echo base_url(); ?>assets/css/slick.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/slick-theme.css" rel="stylesheet" type="text/css" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.min.css" rel="stylesheet" />
        <link href="<?php echo base_url(); ?>assets/css/menu.css" rel="stylesheet" type="text/css"> 
        
        <link href="<?php echo base_url(); ?>assets/main.css?version=6" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/modernizr.custom.26633.js"></script>
		
		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=UA-151414905-1"></script>
		<script>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());

		  gtag('config', 'UA-151414905-1');
		</script>

		<!--Start of Tawk.to Script-->
	<!--	<script type="text/javascript">
		var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
	    (function(){
		var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
	    s1.async=true;
	    s1.src='https://embed.tawk.to/5cfaa9ceb534676f32addf88/default';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
		})();
		</script>-->
		<!--End of Tawk.to Script-->
