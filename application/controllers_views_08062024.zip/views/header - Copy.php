    <header>
            <div class="topheader">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-1"></div>
                        <div class="col-lg-5 col-md-7">
                            <ul class="topleftlist">
                                <li><a href=""><?php echo $this->Common_model->show_parameter(3); ?></a></li>
                                <li><a href=""><?php echo $this->Common_model->show_parameter(2); ?></a></li>
                            </ul>
                        </div>

                        <div class="col-lg-5 col-md-5">
                            <ul class="toprightlist">
                                <li><a href="<?php echo base_url()?>login">Login</a></li>
                                <li><a href="<?php echo base_url()?>signup">Sign Up</a></li>
                            </ul>
                        </div>

                        <div class="col-lg-1"></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>

            <div class="logoheader" data-toggle="sticky-onscroll">
                <div class="container-fluid menuholder">
                    <div class="droopmenu-navbar">
                        <div class="droopmenu-inner">
                            <div class="droopmenu-header">
                                <a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/images/logo.png" class="img-fluid mt-2" alt="logo"></a>
                                <a href="#" class="droopmenu-toggle"></a>
                            </div>

                            <div class="droopmenu-nav">                     

                                <ul class="droopmenu">
                                    <li><a href="<?php echo base_url(); ?>">Home</a></li>

                                    <?php
                                                $menus = $this->Common_model->get_records("menuid, menu_name","tbl_menus","status=1 ","menuid DESC","","");
                                                if( !empty($menus) )
                                                {
                                                    foreach ($menus as $menu)
                                                    {
                                                        $menu_id = $menu['menuid'];
                                                        $menu_name = $menu['menu_name'];
                                                        $seomenu = $this->Common_model->makeSeoUrl($menu_name);
                                                      
                                            ?>


                                    <li><a href="#"><?php echo $menu_name; ?></a>
                                        <ul class="droopmenu-megamenu droopmenu-grid">
                                            <li class="droopmenu-tabs droopmenu-tabs-vertical">
                                             

                                             <?php
                                                $submenus = $this->Common_model->get_records("*","tbl_menucateories","menuid=$menu_id and status=1 ","cat_name DESC","","");
                                                if( !empty($submenus) )
                                                {
                                                    foreach ($submenus as $submenu)
                                                    {

                                                        $cat_id = $submenu['catid'];
                                                        $submenu_id = $submenu['menuid'];
                                                        $submenu_name = $submenu['cat_name'];
                                            ?>


                                                <!-- TAB ONE -->
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader"><?php echo $submenu_name; ?></a>
                                                    <div class="droopmenu-tabcontent">
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">
                                                              <?php
                                                        $menutags = $this->Common_model->get_records("*","tbl_menutags","cat_id='$cat_id' and status=1","tag_name ASC","","");
                                                        if( !empty($menutags))
                                                        {
                                                            foreach ($menutags as $menutag)
                                                            {

                                                                $tagid = $menutag['tagid'];
                                                                $tag_name = $menutag['tag_name'];
                                                                $seotag_name = $this->Common_model->makeSeoUrl($tag_name);
                                                      
                                                          ?>
                                                                <li><a href="#"><?php echo $tag_name; ?></a></li>

															<?php
																}
															}  

														else{
													?> 

															<?php
												$destitags = $this->Common_model->get_records("*","tbl_destination_cats","cat_id='$cat_id' ","","","");

                                                        if( !empty($destitags))
                                                        {
                                                            foreach ($destitags as $destitag)
                                                            {

                                                                $destcat_id = $destitag['destcat_id'];
                                                                $destination_id = $destitag['destination_id']; 
                                                               
                                                                $destinationname=$this->Common_model->showname_fromid("destination_name","tbl_destination","destination_id='$destination_id'");

                                                                $destinationurl=$this->Common_model->showname_fromid("destination_url","tbl_destination","destination_id='$destination_id'");
                                                      
                                                          ?>
     


                                                                 <li><a href="<?php echo base_url() . 'destination/' . $destinationurl; ?>"><?php echo $destinationname; ?></a></li>

                                                             <?php  } } }?>


                                                               <!--  <li><a href="#">Kerala Tour Packages</a></li>
                                                                <li><a href="#">Golden Triangle</a></li>
                                                                <li><a href="#">Goa Tour Packages</a></li>
                                                                <li><a href="#">Himachal Tours</a></li>
                                                                <li><a href="#">Rajasthan Tour Packages</a></li>
                                                                <li><a href="#">Andaman Tour  Packages</a></li>
                                                                <li><a href="#">Karnataka Tours</a></li>
                                                                <li><a href="#">Uttarakhand Packages</a></li>
                                                                <li><a href="#">Coorg Tour Packages</a></li>
                                                                <li><a href="#">Ooty Tour Packages</a></li>
                                                                <li><a href="#">Simla Tours</a></li>
                                                                <li><a href="#">Mysore Tour Packages</a></li>
                                                                <li><a href="#">Best Nainital Tours</a></li>
                                                                <li><a href="#">Munnar Packages</a></li>
                                                                <li><a href="#">Mahabaleswar Tours</a></li>
                                                                <li><a href="#">Kodaikanal Packages</a></li>
                                                                <li><a href="#">Chikmagalur Packages</a></li>
                                                                <li><a href="#">Summer Gateways</a></li>
                                                                <li><a href="#">Monsoon Tour Packages</a></li> -->

                                                                


                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <li><img src="<?php echo base_url(); ?>assets/images/mahabaleshwar-destination.jpg" alt="" class="img-fluid"></li>
                                                            </ul>                                                                                              
                                                        </div>
                                                    </div>
                                                </div>

                                                   <?php
                                                    }
                                                }
                                            ?>      

                                                <!-- TAB TWO -->
                                               <!--  <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Offbeat Tours</a>
                                                    <div class="droopmenu-tabcontent">                                            
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Chikmagalur</a></li>
                                                                <li><a href="#">Coorg</a></li>
                                                                <li><a href="#">Yercaud</a></li>
                                                                <li><a href="#">Almora</a></li>
                                                                <li><a href="#">Aurangabad</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <li> <img src="<?php //echo base_url(); ?>assets/images/goa-destination.jpg" alt="" class="img-fluid"></li>
                                                            </ul>                                                                                              
                                                        </div>                                      
                                                    </div>
                                                </div> -->

                                                <!-- TAB THREE -->
                                               <!--  <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Explore around your City</a>
                                                    <div class="droopmenu-tabcontent">
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Lonavala</a></li>
                                                                <li><a href="#">Panchgani</a></li>
                                                                <li><a href="#">Pondicherry</a></li>
                                                                <li><a href="#">Wayanad</a></li>
                                                                <li><a href="#">Puri</a></li>
                                                                <li><a href="#">Mussoorie</a></li>
                                                                <li><a href="#">Satara</a></li>
                                                                <li><a href="#">Madurai</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <img src="<?php //echo base_url(); ?>assets/images/wayanad.jpg" alt="" class="img-fluid">
                                                            </ul>                                                                                             
                                                        </div>                                           
                                                    </div>
                                                </div> -->

                                                <!-- TAB FOUR -->
                                                <!-- <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Recommeded Tour Packages</a>
                                                    <div class="droopmenu-tabcontent">
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Andhra Pradesh</a></li>
                                                                <li><a href="#">Himachal</a></li>
                                                                <li><a href="#">Karnataka</a></li>
                                                                <li><a href="#">Kerala</a></li>
                                                                <li><a href="#">Maharashtra</a></li>
                                                                <li><a href="#">Tamilnadu</a></li>
                                                                <li><a href="#">Telangana</a></li>
                                                                <li><a href="#">Uttarakhand</a></li>
                                                                <li><a href="#">Rajasthan</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <li><img src="<?php //echo base_url(); ?>assets/images/ooty.jpg" alt="" class="img-fluid"></li>
                                                            </ul>                                                    
                                                        </div>                                   
                                                    </div>
                                                </div> -->

                                            </li>
                                        </ul>
                                    </li>

                                             <?php
                                                    }
                                                }
                                            ?>      


                                    <!-- <li><a href="#">Destinations</a>
                                        <ul class="droopmenu-megamenu droopmenu-grid">
                                            <li class="droopmenu-tabs droopmenu-tabs-vertical">
                                                
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Most Popular Destinations</a>
                                                    <div class="droopmenu-tabcontent">
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Delhi</a></li>
                                                                <li><a href="#">Agra</a></li>
                                                                <li><a href="#">Jaipur</a></li>
                                                                <li><a href="#">Udaipur</a></li>
                                                                <li><a href="#">Shimla</a></li>
                                                                <li><a href="#">Manali</a></li>
                                                                <li><a href="#">Munnar</a></li>
                                                                <li><a href="#">Thekkady</a></li>
                                                                <li><a href="#">Alleppey</a></li>
                                                                <li><a href="#">Darjeeling</a></li>
                                                                <li><a href="#">Goa</a></li>
                                                                <li><a href="#">Coorg</a></li>
                                                                <li><a href="#">OOty</a></li>
                                                                <li><a href="#">Andamans</a></li>
                                                                <li><a href="#">Nainital</a></li>
                                                                <li><a href="#">Hampi</a></li>
                                                                <li><a href="#">Mysore</a></li>
                                                                <li><a href="#">Kodaikanal</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <li><img src="<?php //echo base_url(); ?>assets/images/mahabaleshwar-destination.jpg" alt="" class="img-fluid"></li>
                                                            </ul>                                                                                              
                                                        </div>
                                                    </div>
                                                </div>

                                              
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Trending Now</a>
                                                    <div class="droopmenu-tabcontent">                                            
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Chikmagalur</a></li>
                                                                <li><a href="#">Coorg</a></li>
                                                                <li><a href="#">Yercaud</a></li>
                                                                <li><a href="#">Almora</a></li>
                                                                <li><a href="#">Aurangabad</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <li><img src="<?php //echo base_url(); ?>assets/images/goa-destination.jpg" alt="" class="img-fluid"></li>
                                                            </ul>                                                                                              
                                                        </div>                                
                                                    </div>
                                                </div>

                                                
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Quick Breaks</a>
                                                    <div class="droopmenu-tabcontent">
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Lonavala</a></li>
                                                                <li><a href="#">Panchgani</a></li>
                                                                <li><a href="#">Pondicherry</a></li>
                                                                <li><a href="#">Wayanad</a></li>
                                                                <li><a href="#">Puri</a></li>
                                                                <li><a href="#">Mussoorie</a></li>
                                                                <li><a href="#">Satara</a></li>
                                                                <li><a href="#">Madurai</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <img src="<?php //echo base_url(); ?>assets/images/wayanad.jpg" alt="" class="img-fluid">
                                                            </ul>                                                                                             
                                                        </div>                      
                                                    </div>
                                                </div>

                                               
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Explore States</a>
                                                    <div class="droopmenu-tabcontent">
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Andhra Pradesh</a></li>
                                                                <li><a href="#">Himachal</a></li>
                                                                <li><a href="#">Karnataka</a></li>
                                                                <li><a href="#">Kerala</a></li>
                                                                <li><a href="#">Maharashtra</a></li>
                                                                <li><a href="#">Tamilnadu</a></li>
                                                                <li><a href="#">Telangana</a></li>
                                                                <li><a href="#">Uttarakhand</a></li>
                                                                <li><a href="#">Rajasthan</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <li> <img src="<?php //echo base_url(); ?>assets/images/ooty.jpg" alt="" class="img-fluid"></li>
                                                            </ul>                                                    
                                                        </div>                               
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>

                                    </li> -->
                                    <!-- <li class="droopmenu-parent" aria-haspopup="true">
                                        <a href="#">Gateways</a>
                                        <ul>

                                            <li><a href="#">Gateways of the season</a></li>
                                            <li><a href="#">Bangalore weekend gateways</a></li>
                                            <li><a href="#">Delhi weekend gateways</a></li>
                                            <li><a href="#">Explore your favorite   States</a></li>
                                        </ul>
                                    </li> -->
                                    <li><a href="<?php echo base_url()?>blog">Blog<em class="droopmenu-topanim"></em></a></li>
                                    <li><a href="<?php echo base_url()?>contactus">contact us<em class="droopmenu-topanim"></em></a></li>
                                </ul>
                            </div>

                            <!-- droopmenu-nav -->
                            <div class="droopmenu-extra">
                                <div class="droopmenu mt-3 search">
                                    <div class="input-group">
                                        <input class="form-control border-secondary" type="search" placeholder="Search Destination">
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="button">
                                                <i class="fa fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
