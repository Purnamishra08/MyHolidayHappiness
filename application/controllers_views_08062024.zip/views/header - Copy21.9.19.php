    <header>
            <div class="topheader">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-1"></div>
                        <div class="col-lg-5 col-md-7">
                            <ul class="topleftlist">
                                <li><a href="">+91-7799591230</a></li>
                                <li><a href="">contact@toursandtravel.com</a></li>
                            </ul>
                        </div>

                        <div class="col-lg-5 col-md-5">
                            <ul class="toprightlist">
                                <li><a href="<?php echo base_url()?>login">Login</a></li>
                                <li><a href="<?php echo base_url()?>signup">Sign Up</a></li>
                            </ul>
                        </div>

                        <div class="col-lg-1"></div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>

            <div class="logoheader" data-toggle="sticky-onscroll">
                <div class="container-fluid menuholder">
                    <div class="droopmenu-navbar">
                        <div class="droopmenu-inner">
                            <div class="droopmenu-header">
                                <a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/images/logo.png" class="img-fluid mt-2" alt="logo"></a>
                                <a href="#" class="droopmenu-toggle"></a>
                            </div>

                            <div class="droopmenu-nav">                     

                                <ul class="droopmenu">
                                    <li><a href="<?php echo base_url(); ?>">Home</a></li>
                                    <li><a href="#">Tours</a>
                                        <ul class="droopmenu-megamenu droopmenu-grid">
                                            <li class="droopmenu-tabs droopmenu-tabs-vertical">
                                                <!-- TAB ONE -->
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Popular Tour Packages</a>
                                                    <div class="droopmenu-tabcontent">
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Honeymoon Packages</a></li>
                                                                <li><a href="#">Kerala Tour Packages</a></li>
                                                                <li><a href="#">Golden Triangle</a></li>
                                                                <li><a href="#">Goa Tour Packages</a></li>
                                                                <li><a href="#">Himachal Tours</a></li>
                                                                <li><a href="#">Rajasthan Tour Packages</a></li>
                                                                <li><a href="#">Andaman Tour  Packages</a></li>
                                                                <li><a href="#">Karnataka Tours</a></li>
                                                                <li><a href="#">Uttarakhand Packages</a></li>
                                                                <li><a href="#">Coorg Tour Packages</a></li>
                                                                <li><a href="#">Ooty Tour Packages</a></li>
                                                                <li><a href="#">Simla Tours</a></li>
                                                                <li><a href="#">Mysore Tour Packages</a></li>
                                                                <li><a href="#">Best Nainital Tours</a></li>
                                                                <li><a href="#">Munnar Packages</a></li>
                                                                <li><a href="#">Mahabaleswar Tours</a></li>
                                                                <li><a href="#">Kodaikanal Packages</a></li>
                                                                <li><a href="#">Chikmagalur Packages</a></li>
                                                                <li><a href="#">Summer Gateways</a></li>
                                                                <li><a href="#">Monsoon Tour Packages</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <li><img src="<?php echo base_url(); ?>assets/images/mahabaleshwar-destination.jpg" alt="" class="img-fluid"></li>
                                                            </ul>                                                                                              
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- TAB TWO -->
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Offbeat Tours</a>
                                                    <div class="droopmenu-tabcontent">                                            
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Chikmagalur</a></li>
                                                                <li><a href="#">Coorg</a></li>
                                                                <li><a href="#">Yercaud</a></li>
                                                                <li><a href="#">Almora</a></li>
                                                                <li><a href="#">Aurangabad</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <li> <img src="<?php echo base_url(); ?>assets/images/goa-destination.jpg" alt="" class="img-fluid"></li>
                                                            </ul>                                                                                              
                                                        </div><!-- droopmenu-row -->                                            
                                                    </div><!-- droopmenu-tabcontent -->
                                                </div><!-- droopmenu-tabsection -->

                                                <!-- TAB THREE -->
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Explore around your City</a>
                                                    <div class="droopmenu-tabcontent">
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Lonavala</a></li>
                                                                <li><a href="#">Panchgani</a></li>
                                                                <li><a href="#">Pondicherry</a></li>
                                                                <li><a href="#">Wayanad</a></li>
                                                                <li><a href="#">Puri</a></li>
                                                                <li><a href="#">Mussoorie</a></li>
                                                                <li><a href="#">Satara</a></li>
                                                                <li><a href="#">Madurai</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <img src="<?php echo base_url(); ?>assets/images/wayanad.jpg" alt="" class="img-fluid">
                                                            </ul>                                                                                             
                                                        </div><!-- droopmenu-row -->                                             
                                                    </div><!-- droopmenu-tabcontent -->
                                                </div><!-- droopmenu-tabsection -->

                                                <!-- TAB FOUR -->
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Recommeded Tour Packages</a>
                                                    <div class="droopmenu-tabcontent">
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Andhra Pradesh</a></li>
                                                                <li><a href="#">Himachal</a></li>
                                                                <li><a href="#">Karnataka</a></li>
                                                                <li><a href="#">Kerala</a></li>
                                                                <li><a href="#">Maharashtra</a></li>
                                                                <li><a href="#">Tamilnadu</a></li>
                                                                <li><a href="#">Telangana</a></li>
                                                                <li><a href="#">Uttarakhand</a></li>
                                                                <li><a href="#">Rajasthan</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <li><img src="<?php echo base_url(); ?>assets/images/ooty.jpg" alt="" class="img-fluid"></li>
                                                            </ul>                                                    
                                                        </div>                                   
                                                    </div>
                                                </div>

                                            </li>
                                        </ul>
                                    </li>


                                    <li><a href="#">Destinations</a>
                                        <ul class="droopmenu-megamenu droopmenu-grid">
                                            <li class="droopmenu-tabs droopmenu-tabs-vertical">
                                                <!-- TAB ONE -->
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Most Popular Destinations</a>
                                                    <div class="droopmenu-tabcontent">
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Delhi</a></li>
                                                                <li><a href="#">Agra</a></li>
                                                                <li><a href="#">Jaipur</a></li>
                                                                <li><a href="#">Udaipur</a></li>
                                                                <li><a href="#">Shimla</a></li>
                                                                <li><a href="#">Manali</a></li>
                                                                <li><a href="#">Munnar</a></li>
                                                                <li><a href="#">Thekkady</a></li>
                                                                <li><a href="#">Alleppey</a></li>
                                                                <li><a href="#">Darjeeling</a></li>
                                                                <li><a href="#">Goa</a></li>
                                                                <li><a href="#">Coorg</a></li>
                                                                <li><a href="#">OOty</a></li>
                                                                <li><a href="#">Andamans</a></li>
                                                                <li><a href="#">Nainital</a></li>
                                                                <li><a href="#">Hampi</a></li>
                                                                <li><a href="#">Mysore</a></li>
                                                                <li><a href="#">Kodaikanal</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <li><img src="<?php echo base_url(); ?>assets/images/mahabaleshwar-destination.jpg" alt="" class="img-fluid"></li>
                                                            </ul>                                                                                              
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- TAB TWO -->
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Trending Now</a>
                                                    <div class="droopmenu-tabcontent">                                            
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Chikmagalur</a></li>
                                                                <li><a href="#">Coorg</a></li>
                                                                <li><a href="#">Yercaud</a></li>
                                                                <li><a href="#">Almora</a></li>
                                                                <li><a href="#">Aurangabad</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <li><img src="<?php echo base_url(); ?>assets/images/goa-destination.jpg" alt="" class="img-fluid"></li>
                                                            </ul>                                                                                              
                                                        </div>                                
                                                    </div>
                                                </div>

                                                <!-- TAB THREE -->
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Quick Breaks</a>
                                                    <div class="droopmenu-tabcontent">
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Lonavala</a></li>
                                                                <li><a href="#">Panchgani</a></li>
                                                                <li><a href="#">Pondicherry</a></li>
                                                                <li><a href="#">Wayanad</a></li>
                                                                <li><a href="#">Puri</a></li>
                                                                <li><a href="#">Mussoorie</a></li>
                                                                <li><a href="#">Satara</a></li>
                                                                <li><a href="#">Madurai</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <img src="<?php echo base_url(); ?>assets/images/wayanad.jpg" alt="" class="img-fluid">
                                                            </ul>                                                                                             
                                                        </div>                      
                                                    </div>
                                                </div>

                                                <!-- TAB FOUR -->
                                                <div class="droopmenu-tabsection">
                                                    <a href="#" class="droopmenu-tabheader">Explore States</a>
                                                    <div class="droopmenu-tabcontent">
                                                        <div class="droopmenu-row">
                                                            <ul class="droopmenu-col droopmenu-col8">                                                 
                                                                <li><a href="#">Andhra Pradesh</a></li>
                                                                <li><a href="#">Himachal</a></li>
                                                                <li><a href="#">Karnataka</a></li>
                                                                <li><a href="#">Kerala</a></li>
                                                                <li><a href="#">Maharashtra</a></li>
                                                                <li><a href="#">Tamilnadu</a></li>
                                                                <li><a href="#">Telangana</a></li>
                                                                <li><a href="#">Uttarakhand</a></li>
                                                                <li><a href="#">Rajasthan</a></li>
                                                            </ul>
                                                            <ul class="droopmenu-col droopmenu-col4 listimage"> 
                                                                <li> <img src="<?php echo base_url(); ?>assets/images/ooty.jpg" alt="" class="img-fluid"></li>
                                                            </ul>                                                    
                                                        </div>                               
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>

                                    </li>
                                    <li class="droopmenu-parent" aria-haspopup="true">
                                        <a href="#">Gateways</a>
                                        <ul>

                                            <li><a href="#">Gateways of the season</a></li>
                                            <li><a href="#">Bangalore weekend gateways</a></li>
                                            <li><a href="#">Delhi weekend gateways</a></li>
                                            <li><a href="#">Explore your favorite   States</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="<?php echo base_url()?>blog">Blog<em class="droopmenu-topanim"></em></a></li>
                                    <li><a href="<?php echo base_url()?>contactus">contact us<em class="droopmenu-topanim"></em></a></li>
                                </ul>
                            </div>

                            <!-- droopmenu-nav -->
                            <div class="droopmenu-extra">
                                <div class="droopmenu mt-3 search">
                                    <div class="input-group">
                                        <input class="form-control border-secondary" type="search" placeholder="Search Destination">
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="button">
                                                <i class="fa fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>