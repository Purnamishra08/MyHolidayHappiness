<!doctype html>
<html>
	<head>
		<?php include("head.php"); ?> 
	</head>
    <body>
      <?php include("header.php"); ?> 

        <div class="videocontainer">
            <video autoplay="" muted="" loop="" id="myVideo">
                <source src="<?php echo base_url(); ?>assets/images/mainvdo.mp4" type="video/mp4"> </video>

            <div class="formcontainer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center mb-3">
                            <h1 style="color:white">Love where you are going</h1>
                            <p style="color:white">Nam dapibus nisl vitae elit fringilla rutrum. Aenean sollicitudin, erat a elementum rutrum.</p>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-2"></div>
                        <form class="col-md-8 row bookingform-container">
                            <div class="col-lg-5 col-md-12 formbox selectdiv currentlocationbox">
                                <div class="form-group">
                                    <i class="pe-7s-map-marker"></i>
                                    <label for="destination" class="mt-3 labelheading">Destination</label>
                                    <select class="selectpicker" data-live-search="true"  data-live-search-placeholder="Search">
                                        <option data-tokens="">Delhi</option>
                                        <option data-tokens="">Darjeeling</option>
                                        <option data-tokens="">Andamans</option>
                                        <option data-tokens="">Agra</option>
                                        <option data-tokens="">Jaipur</option>
                                        <option data-tokens="">Udaipur</option>
                                        <option data-tokens="">Simla</option>
                                        <option data-tokens="">Ooty</option>
                                        <option data-tokens="">Coorg</option>
                                        <option data-tokens="">Nainital</option>
                                        <option data-tokens="">Rajasthan</option>
                                        <option data-tokens="">Munnar</option>							
                                        <option data-tokens=" ">Manali</option>
                                        <option data-tokens="">Mysore</option>
                                        <option data-tokens="">Kodaikanal</option>
                                        <option data-tokens="">Aurangabad</option>
                                        <option data-tokens="">Lonavala</option>
                                        <option data-tokens="">Panchgani</option>
                                        <option data-tokens=" ">Wayanad</option>
                                        <option data-tokens="">Satara</option>
                                        <option data-tokens="">Madurai</option>
                                        <option data-tokens="">Pondicherry</option>
                                        <option data-tokens="">Andhra Pradesh</option>
                                        <option data-tokens="">Himachal Pradesh</option></select>
                                </div>
                            </div>

                            <div class="col-lg-5 col-md-12 formbox selectdiv destinationbox">
                                <div class="form-group">
                                    <i class="pe-7s-clock"></i>
                                    <label for="duration" class="mt-3 labelheading">Duration</label>
                                    <select class="selectpicker" data-live-search="true"  data-live-search-placeholder="Search" >							
                                        <option data-tokens="">3Days/2Nights</option>
                                        <option data-tokens="">2Days/1Nights</option>
                                        <option data-tokens="">5Days/4Nights</option>
                                        <option data-tokens="">6Days/5Nights</option>
                                        <option data-tokens="">7Days/6Nights</option></select>
                                </div>
                            </div>

                            <div class="col-lg-2 col-md-12 formsubmitbutton">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                            <div class="clearfix"></div>
                        </form>
                        <div class="col-md-2"></div> <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>

        <section class="featuredsection">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="featuredbox-top">
                            <img src="<?php echo base_url(); ?>assets/images/guide.png">
                            <div class="featuredbox-title"><span>1,000+</span> local guides </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="featuredbox-top">
                            <img src="<?php echo base_url(); ?>assets/images/experience.png">
                            <div class="featuredbox-title"><span>Handcrafted</span> experiences </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="featuredbox-top">
                            <img src="<?php echo base_url(); ?>assets/images/traveller.png">
                            <div class="featuredbox-title"><span>96% </span> happy travellers</div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </section>

        <section class="bg01">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-12">
                        <h2>Most Popular Tours</h2>
                        <p class="headingcontent">check out our best promotion tours!</p>
                    </div>
                    <div class="col-lg-3 col-md-12">
                        <a href="tour-packages.html" class="morebutton mt-3">View all tours</a>
                    </div><div class="clearfix"></div>

                    <div class="col-xl-3 col-lg-4 col-md-6 touristlist-box">
                        <div class="tour-item">

                            <h3 class="tour-heading"><a href="#">Coorg Tour Packages</a></h3>
                            <div class="tour-head">
                                <div class="corner featuredribbon"><span>Featured</span></div>
                                <a href=""><img src="<?php echo base_url(); ?>assets/images/Kumarakom.jpg" alt="" class="img-fluid"></a>
                                <div class="explore hometag">Ex-Delhi</div>
                            </div>

                            <div class="tour-content">

                                <span class="tour-sub-content">Dubare, Bylakuppe, Madikeri, Talakaveri</span>
                                <div class="tourbutton"><a href="#" class="viwebtn">View details</a></div>

                                <div class="tourprice"><span class="packageCostOrig" style="text-decoration: line-through; color: #A0A0A0; font-size:14px">₹ 6100</span>
                                    <span class="packageCost">₹4850</span></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 touristlist-box">
                        <div class="tour-item">
                            <h3 class="tour-heading"><a href="#">Ooty Tour Packages</a></h3>
                            <div class="tour-head">
                                <a href=""><img src="<?php echo base_url(); ?>assets/images/ooty.jpg" alt="" class="img-fluid"></a>
                                <div class="explore hometag">Ex-Kochi</div>
                            </div>

                            <div class="tour-content">

                                <span class="tour-sub-content">Ooty Lake, Pykara, Ketti, Doddabetta</span>
                                <div class="tourbutton"> <span><a href="#" class="viwebtn">View details</a></span></div>

                                <div class="tourprice"><span class="packageCostOrig" style="text-decoration: line-through; color: #A0A0A0; font-size:14px">₹ 6100</span>
                                    <span class="packageCost">₹4850</span></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 touristlist-box">
                        <div class="tour-item">
                            <h3 class="tour-heading"><a href="#">Wayanad Tour Packages</a></h3>
                            <div class="tour-head">
                                <div class="corner featuredribbon"><span>Featured</span></div>
                                <a href=""><img src="<?php echo base_url(); ?>assets/images/wayanad.jpg" alt="" class="img-fluid"></a>
                                <div class="explore hometag">Ex-Bangalore</div>
                            </div>

                            <div class="tour-content">

                                <span class="tour-sub-content">Bansura, Meenmutty, Edakkal </span>
                                <div class="tourbutton"> <span><a href="#" class="viwebtn">View details</a></span></div>

                                <div class="tourprice"><span class="packageCostOrig" style="text-decoration: line-through; color: #A0A0A0; font-size:14px">₹ 6100</span>
                                    <span class="packageCost">₹4850</span></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 touristlist-box">
                        <div class="tour-item">
                            <h3 class="tour-heading"><a href="#">Munnar Tour Packages</a></h3>
                            <div class="tour-head">
                                <a href=""><img src="<?php echo base_url(); ?>assets/images/munnar.jpg" alt="" class="img-fluid"></a>
                                <div class="explore hometag">Ex-Kerala</div>
                            </div>

                            <div class="tour-content">

                                <span class="tour-sub-content">Dubare, Bylakuppe, Madikeri, Talakaveri</span>
                                <div class="tourbutton"> <span><a href="#" class="viwebtn">View details</a></span></div>

                                <div class="tourprice"><span class="packageCostOrig" style="text-decoration: line-through; color: #A0A0A0; font-size:14px">₹ 6100</span>
                                    <span class="packageCost">₹4850</span></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 touristlist-box">
                        <div class="tour-item">
                            <h3 class="tour-heading"><a href="#">Pondicherry Tour Packages</a></h3>
                            <div class="tour-head">
                                <a href=""><img src="<?php echo base_url(); ?>assets/images/pondicherry.jpg" alt="" class="img-fluid"></a>
                                <div class="explore hometag">Ex-Goa</div>
                            </div>

                            <div class="tour-content">

                                <span class="tour-sub-content">Pondicherry Sightseeing</span>
                                <div class="tourbutton"> <span><a href="#" class="viwebtn">View details</a></span></div>

                                <div class="tourprice"><span class="packageCostOrig" style="text-decoration: line-through; color: #A0A0A0; font-size:14px">₹ 6100</span>
                                    <span class="packageCost">₹4850</span></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 touristlist-box">
                        <div class="tour-item">
                            <h3 class="tour-heading"><a href="#">Kerala Tour Packages</a></h3>
                            <div class="tour-head">
                                <div class="corner featuredribbon"><span>Featured</span></div>
                                <a href=""><img src="<?php echo base_url(); ?>assets/images/kerala.jpg" alt="" class="img-fluid"></a>
                                <div class="explore hometag">Ex-Rajasthan</div>
                            </div>

                            <div class="tour-content">

                                <span class="tour-sub-content">Munnar, Thekkady, Alleppey, Kovalam</span>
                                <div class="tourbutton"> <span><a href="#" class="viwebtn">View details</a></span></div>

                                <div class="tourprice"><span class="packageCostOrig" style="text-decoration: line-through; color: #A0A0A0; font-size:14px">₹ 6100</span>
                                    <span class="packageCost">₹4850</span></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 touristlist-box">
                        <div class="tour-item">
                            <h3 class="tour-heading"><a href="#">Kerala Tour Packages</a></h3>
                            <div class="tour-head">
                                <a href=""><img src="<?php echo base_url(); ?>assets/images/kerala.jpg" alt="" class="img-fluid"></a>
                                <div class="explore hometag">Ex-Delhi</div>
                            </div>

                            <div class="tour-content">

                                <span class="tour-sub-content">Munnar, Thekkady, Alleppey, Kovalam</span>
                                <div class="tourbutton"> <span><a href="#" class="viwebtn">View details</a></span></div>

                                <div class="tourprice"><span class="packageCostOrig" style="text-decoration: line-through; color: #A0A0A0; font-size:14px">₹ 6100</span>
                                    <span class="packageCost">₹4850</span></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 touristlist-box">
                        <div class="tour-item">
                            <h3 class="tour-heading"><a href="#">Kerala Tour Packages</a></h3>
                            <div class="tour-head">
                                <div class="corner featuredribbon"><span>Featured</span></div>
                                <a href=""><img src="<?php echo base_url(); ?>assets/images/kerala.jpg" alt="" class="img-fluid"></a>
                                <div class="explore hometag">Ex-Sikkim</div>
                            </div>

                            <div class="tour-content">

                                <span class="tour-sub-content">Munnar, Thekkady, Alleppey, Kovalam</span>
                                <div class="tourbutton"> <span><a href="#" class="viwebtn">View details</a></span></div>

                                <div class="tourprice"><span class="packageCostOrig" style="text-decoration: line-through; color: #A0A0A0; font-size:14px">₹ 6100</span>
                                    <span class="packageCost">₹4850</span></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </section>

        <section class="destinationsection">
            <div class="destinationtop">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 destinationholder">
                            <a href="#">
                                <div class="newimg">
                                    <img src="<?php echo base_url(); ?>assets/images/kerala-destination.jpg" alt="">
                                </div>
                                <div class="padcontent">
                                    <p>Kerala</p>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-3 col-md-6 destinationholder">
                            <a href="#">
                                <div class="newimg">
                                    <img src="<?php echo base_url(); ?>assets/images/goa-destination.jpg" alt="">
                                </div>
                                <div class="padcontent">
                                    <p>Goa</p>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-3 col-md-6 destinationholder">
                            <a href="#">
                                <div class="newimg">
                                    <img src="<?php echo base_url(); ?>assets/images/coorg-destination.jpg" alt="">
                                </div>
                                <div class="padcontent">
                                    <p>Coorg</p>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-3 col-md-6 destinationholder">
                            <a href="#">
                                <div class="newimg">
                                    <img src="<?php echo base_url(); ?>assets/images/ooty-destination.jpg" alt="">
                                </div>
                                <div class="padcontent">
                                    <p>Ooty</p>
                                </div>
                            </a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>

            <div class="destinationmiddle">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-3 destinationholder">
                            <a href="#">
                                <div class="newimg">
                                    <img src="<?php echo base_url(); ?>assets/images/rajasthan-destination.jpg" alt="">
                                </div>
                                <div class="padcontent">
                                    <p>Rajasthan</p>
                                </div>
                            </a>
                        </div>

                        <div class="col-md-6 destinationcontent text-center">
                            <h3>Our top Destinations</h3>
                            <a href="destinations.html" class="morebutton">View all tours</a>
                        </div>

                        <div class="col-md-3 destinationholder">
                            <a href="golden-triangle.html">
                                <div class="newimg">
                                    <img src="<?php echo base_url(); ?>assets/images/temple-destination.jpg" alt="">
                                </div>
                                <div class="padcontent">
                                    <p>Golden Traingle</p>
                                </div>
                            </a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>

            <div class="destinationbottom">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 destinationholder">
                            <a href="#">
                                <div class="newimg">
                                    <img src="<?php echo base_url(); ?>assets/images/himachal-destination.jpg" alt="">
                                </div>
                                <div class="padcontent">
                                    <p>Himachal Pradesh</p>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-3 col-md-6 destinationholder">
                            <a href="#">
                                <div class="newimg">
                                    <img src="<?php echo base_url(); ?>assets/images/uttarakhand-destination.jpg" alt="">
                                </div>
                                <div class="padcontent">
                                    <p>Uttarakhand</p>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-3 col-md-6 destinationholder">
                            <a href="" title="">
                                <div class="newimg">
                                    <img src="<?php echo base_url(); ?>assets/images/mahabaleshwar-destination.jpg" alt="">
                                </div>
                                <div class="padcontent">
                                    <p>Mahabaleswar</p>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-3 col-md-6 destinationholder">
                            <a href="" title="">
                                <div class="newimg">
                                    <img src="<?php echo base_url(); ?>assets/images/tamilnadu-destination.jpg" alt="">
                                </div>
                                <div class="padcontent">
                                    <p>Tamilnadu</p>
                                </div>
                            </a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </section>

        <section class="destination-season">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <h3 class="mt-2">Destinations of the season</h3> </div>
                    <div class="col-md-6 mb-4"><a href="destinations.html" class="morebutton">View all destinations</a></div>
                    <div class="clearfix"></div>

                    <div class="col-md-8 seasondestination">
                        <a href="#">
                            <div class="seasondestination-imgholder">
                                <img src="<?php echo base_url(); ?>assets/images/kodaikana.jpg" class="img-fluid">
                            </div>
                            <div class="padcontent">
                                <p>Tamilnadu</p>
                            </div>
                        </a>
                    </div>

                    <div class="col-md-4 seasondestination">
                        <a href="#">
                            <div class="seasondestination-imgholder">
                                <img src="<?php echo base_url(); ?>assets/images/kerala-season.jpg" class="img-fluid">
                            </div>
                            <div class="padcontent">
                                <p>Kerala</p>
                            </div>
                        </a>
                    </div>
                    <div class="clearfix"></div>

                    <div class="col-md-4 seasondestination">
                        <a href="#">
                            <div class="seasondestination-imgholder">
                                <img src="<?php echo base_url(); ?>assets/images/rajasthan-season.jpg" class="img-fluid">
                            </div>
                            <div class="padcontent">
                                <p>Rajasthan</p>
                            </div>
                        </a>
                    </div>

                    <div class="col-md-4 seasondestination">
                        <a href="#">
                            <div class="seasondestination-imgholder">
                                <img src="<?php echo base_url(); ?>assets/images/andaman-season.jpg" class="img-fluid">
                            </div>
                            <div class="padcontent">
                                <p>Andamans</p>
                            </div>
                        </a>
                    </div>

                    <div class="col-md-4 seasondestination">
                        <a href="#">
                            <div class="seasondestination-imgholder">
                                <img src="<?php echo base_url(); ?>assets/images/himachal-season.jpg" class="img-fluid">
                            </div>
                            <div class="padcontent">
                                <p>Tamilnadu</p>
                            </div>
                        </a>
                    </div>

                </div>
            </div>
        </section>

        <section class="weekend-destinations">
            <div class="container weekendcontainer">
                <div class="row">
                    <div class="col-md-12 mb-5 text-center">
                        <h3 class="weekend-title">Top weekend getways</h3>
                        <a href="" class="morebutton">View all destinations</a>
                    </div>
                </div>

                <div class="weekend-destinations-slider">
                    <div class="col-lg-4">
                        <div class="destination-sliderbox text-center">
                            <img src="<?php echo base_url(); ?>assets/images/ooty-destination.jpg" alt="" class="img-fluid" />
                            <h4>Best mountains in Ooty </h4>
                            <a href="" class="morebutton">View details</a>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="destination-sliderbox text-center">
                            <img src="<?php echo base_url(); ?>assets/images/tamilnadu-destination.jpg" alt="" class="img-fluid" />
                            <h4>Best places in Tamilnadu </h4> <a href="" class="morebutton">View details</a>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="destination-sliderbox text-center">
                            <img src="<?php echo base_url(); ?>assets/images/mahabaleshwar-destination.jpg" alt="" class="img-fluid" />
                            <h4>Best temples in Maharashtra </h4> <a href="" class="morebutton">View details</a>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="destination-sliderbox text-center">
                            <img src="<?php echo base_url(); ?>assets/images/temple-destination.jpg" alt="" class="img-fluid" />
                            <h4>Best places in Tamilnadu</h4> <a href="" class="morebutton">View details</a>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="destination-sliderbox text-center">
                            <img src="<?php echo base_url(); ?>assets/images/rajasthan-destination.jpg" alt="" class="img-fluid" />
                            <h4>Best mountains in Ooty </h4> <a href="" class="morebutton">View details</a>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="destination-sliderbox text-center">
                            <img src="<?php echo base_url(); ?>assets/images/coorg-destination.jpg" alt="" class="img-fluid" />
                            <h4>Best mountains in Ooty </h4> <a href="" class="morebutton">View details</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="itineraries-section">
            <div class="container">
                <div class="itinerariesbg">
                    <div class="row">
                        <div class="col-md-8">
                            <h3 class="mt-3">Popular Itineraries</h3></div>
                        <div class="col-md-4 mb-4"><a href="" class="morebutton">View all</a></div>
                        <div class="clearfix"></div>

                        <div class="col-xl-3 col-lg-6 col-md-6 itinerariesdestination">
                            <a href="#">
                                <div class="itinerariesdestination-imgholder">
                                    <img src="<?php echo base_url(); ?>assets/images/coorg-destination.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="itinerariescontent">2-day Trips from Bangalore</div>
                            </a>
                        </div>

                        <div class="col-xl-3 col-lg-6 col-md-6  itinerariesdestination">
                            <a href="#">
                                <div class="itinerariesdestination-imgholder">
                                    <img src="<?php echo base_url(); ?>assets/images/goa-destination.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="itinerariescontent">2-day Trips from Delhi</div>
                            </a>
                        </div>

                        <div class="col-xl-3 col-lg-6 col-md-6  itinerariesdestination">
                            <a href="#">
                                <div class="itinerariesdestination-imgholder">
                                    <img src="<?php echo base_url(); ?>assets/images/goa-destination.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="itinerariescontent">2-day Trips from Mumbai</div>
                            </a>
                        </div>

                        <div class="col-xl-3 col-lg-6 col-md-6  itinerariesdestination">
                            <a href="#">
                                <div class="itinerariesdestination-imgholder">
                                    <img src="<?php echo base_url(); ?>assets/images/goa-destination.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="itinerariescontent">2-day Trips from Mumbai</div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>        
        </section>

        <section class="map-section mb100">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 mt100">
                        <h3 class="mb-4 text-center">Explore tours on Map</h3>
                        <img src="<?php echo base_url(); ?>assets/images/map.jpg" class="img-fluid" alt="">
                    </div>
                </div>
            </div>
        </section>

        <section class="testimonialsection">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h3 class="mb-4">Recent traveller review</h3>
                        <a href="" class="morebutton  mb-4">View all reviews</a>
                    </div>
                    <div class="clearfix"></div>

                    <div class="testimonial-slider">
                        <div class="col-lg-3">
                            <div class="reviewbox">
                                <div class="clientname mt-2">Omkar Joshi</div>
                                <div class="clientplace">Bangalore</div>
                                <img src="<?php echo base_url(); ?>assets/images/rating.jpg" class="img-fluid rating mb-2" alt="">
                                <p>Very comfortable tour as driver shreedher was on time n familiar n friendly n well behaved n overall good family tour ,tq for arranging memorable tour</p>
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <div class="reviewbox">
                                <div class="clientname mt-2">Omkar Joshi</div>
                                <div class="clientplace">Bangalore</div>
                                <img src="<?php echo base_url(); ?>assets/images/rating.jpg" class="img-fluid rating mb-2" alt="">
                                <p>Very comfortable tour as driver shreedher was on time n familiar n friendly n well behaved n overall good family tour ,tq for arranging memorable tour</p>
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <div class="reviewbox">
                                <div class="clientname mt-2">Endner Michael</div>
                                <div class="clientplace">Bangalore</div>
                                <img src="<?php echo base_url(); ?>assets/images/rating.jpg" class="img-fluid rating mb-2" alt="">
                                <p>Very comfortable tour as driver shreedher was on time n familiar n friendly n well behaved n overall good family tour ,tq for arranging memorable tour</p>
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <div class="reviewbox">
                                <div class="clientname mt-2">Endner Michael</div>
                                <div class="clientplace">Bangalore</div>
                                <img src="<?php echo base_url(); ?>assets/images/rating.jpg" class="img-fluid rating mb-2" alt="">
                                <p>Very comfortable tour as driver shreedher was on time n familiar n friendly n well behaved n overall good family tour ,tq for arranging memorable tour</p>
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <div class="reviewbox">
                                <div class="clientname mt-2">Endner Michael</div>
                                <div class="clientplace">Bangalore</div>
                                <img src="<?php echo base_url(); ?>assets/images/rating.jpg" class="img-fluid rating mb-2" alt="">
                                <p>Very comfortable tour as driver shreedher was on time n familiar n friendly n well behaved n overall good family tour ,tq for arranging memorable tour</p>
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <div class="reviewbox">
                                <div class="clientname mt-2">Endner Michael</div>
                                <div class="clientplace">Bangalore</div>
                                <img src="<?php echo base_url(); ?>assets/images/rating.jpg" class="img-fluid rating mb-2" alt="">
                                <p>Very comfortable tour as driver shreedher was on time n familiar n friendly n well behaved n overall good family tour ,tq for arranging memorable tour</p>
                            </div>
                        </div>

                    </div>	
                </div>
            </div>
        </section>

        <section class="blog-section">
            <div class="container">
                <div class="row mt100">
                    <div class="col-lg-6">
                        <div class="blogleft">
                            <h3 class="mb-4 blogheading">Our blog posts</h3><a href="" class="morebutton">View all</a>
                            <div class="blogimage"><a href="#"><img src="<?php echo base_url(); ?>assets/images/goa-destination.jpg" class="img-fluid" alt=""></a></div>
                            <h4 class="blogtitle"><a href="#">12 stunning places to visit in July in India</a></h4>
                            <p class="blogcontent">Lorem ipsum dolor sit amet, consectetur adipisicing Suscipit tas aperiam Sorem ipsum dolor consectur adipisicing. Lorem ipsum dolor sit amet, consectetur adipisicing.</p>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="row mb-2">
                            <div class="rightbloglist blogimage col-md-6"><a href="#"><img src="<?php echo base_url(); ?>assets/images/andaman-season.jpg" class="img-fluid" alt=""></a></div>
                            <div class="col-md-6">
                                <h4 class="blogtitle mt-3"><a href="#">10 promising festivals and events in India</a></h4>
                                <p class="blogcontent">Lorem ipsum dolor sit amet, consectetur adipisicing Suscipit tas aperiam ipsum dolor sit amet, consectetur adipisicing Suscipit tas aperiam..</p>
                            </div>
                        </div> 

                        <div class="row mb-2">
                            <div class="rightbloglist blogimage col-md-6"><a href="#"><img src="<?php echo base_url(); ?>assets/images/kerala-season.jpg" class="img-fluid" alt=""></a></div>
                            <div class="col-md-6">
                                <h4 class="blogtitle mt-3"><a href="#">12 stunning places to visit in July in India</a></h4>
                                <p class="blogcontent">Lorem ipsum dolor sit amet, consectetur adipisicing Suscipit tas ipsum dolor.sit amet, consectetur adipisicing.consectetur..</p>
                            </div>
                        </div><div class="clearfix"></div>
                    </div>
                </div>              
            </div>   
        </section>

        <div class="modal fade" id="bookingmodal">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Our Booking Policy</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>     
                    </div>
                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="policyterms">
                            <ul>
                                <li>Booking can be modified up to 3 days before the travel date (cancellation / amendment charges apply for hotels along with any price difference for revised date - hotels based on availability)</li>
                                <li>Booking can be cancelled up to 3 days before travel date (below Cancellation Policy applies - no partial cancellation)</li>
                                <li>Itinerary can be changed by adding / removing places (as long as the schedule is not impacted) up to 3 days before the travel date. Any extra kilo-meters added due to itinerary change is payable directly to the cab driver.</li>
                                <li>Vehicle can be upgraded to the next category by paying the fare difference up to 3 days before the travel date</li>
                                <li>For multi-day trips, free pick-up &amp; drop from your location within city limits (Ex: BBMP limits for Bengaluru, GHMC limits for Hyderabad, etc). All one day trips start from city center (Ex: Majestic for Bangalore).</li>
                                <li>Standard Hotel check-in time is usually between 12 PM - 2 PM &amp; check-out time is between 10 AM to 12 PM. Early check-in is subject to availability &amp; hotel may charge extra (not included in the tour price). In case of late check-in, please inform the hotel about your arrival time.</li>
                                <li>In case you arrive before check-in time &amp; free rooms are unavailable, you can fresh-up in hotel washroom and proceed with sightseeing until your check-in time.</li>
                                <li>Customers should be ready for sightseeing at Start Time mentioned in the itinerary in order to cover all the places in itinerary. Sightseeing can't extend beyond 7 PM and any places missed can't be covered on following day.</li>
                                <li>Sightseeing is limited to the places mentioned in the itinerary. If time permits, you may visit additional places (not mentioned in itinerary) by paying for extra kilo-meters to the cab driver.</li>
                                <li>In case of natural disasters or cab strike, your tour may be cancelled by Trawell.in and 100% of your booking amount will be refunded</li>
                                <li>In extreme cases, your tour may be cancelled by Trawell.in for unavoidable reasons (within 24 hours of booking) and 100% of your booking amount will be refunded</li>
                                <li>In rare cases, the primary hotel mentioned in the tour page may be unavailable. You will be offered alternate accommodation in the same or higher category. If you are not satisfied with alternate hotel, you may choose to cancel the tour (100% of booking amount will be refunded).</li>
                                <li>Hotel rooms are provided on twin sharing basis. In case of 3 adults or child above 5 years, 3-sharing room or Room with extra bed/mattress will be provided</li>
                                <li>Wherever room category is not mentioned in the quote / website, Base category room will be provided</li>
                                <li>Hotel may deny check-in for unmarried couple and no refund will be issued in such cases</li>
                                <li>Please check weekly off days for sightseeing places. Also, few places may be closed due to heavy rains / maintenance without prior intimation &amp; we have no control on such incidents. Wherever possible, alternate sightseeing may be arranged in such cases.</li>
                                <li>Entry Fees &amp; Activity Fees may change without any intimation and we have no control on the same. All fees mentioned in our website are for Indian nationals.</li>
                                <li>Any special requests like English/Hindi driver is based on availability and can't be guaranteed</li>
                                <li>Refund for cancelled tours usually takes around 7-10 business days</li>
                                <li>Additional charges may apply for Airport Pick-up/Drop (select Airport Pickup option from Additional Options popup on Tour Page)</li>
                                <li>Any issues encountered during the trip need to be resolved with Tour Manager immediately during the trip. Issues can't be addressed after completion of the trip.</li>
                                <li>Trawell.in liability is limited to providing cab &amp; hotel. Sightseeing is complementary and it carries no liability. While we try our best to cover all places in the itinerary, no refund will be issued for sightseeing missed during the trip.</li>
                                <li>Any service issues related to Vehicle &amp; Accommodation need to be resolved with the service provider directly, while Trawell.in can help facilitate the communication</li>
                                <li>Vehicles Provided (all vehicles are A/C only) : Hatchback - Indica V2, Swift, Ritz, similar; Sedan - Dzire, Etios, Fiesta, Xcent, Amaze, similar; SUV - Innova, Xylo, or similar</li>
                                <li>Hotel Voucher will be shared within 2 working hours from the time of booking</li>
                                <li>All Hotels are booked in the name of Primary Traveler mentioned at the time of booking. Any change in guest name is considered as tour canceled and rebooked - cancellation charges apply &amp; hotels based on availability. Valid ID &amp; Address proof need to be carried for all guests including children.</li>
                                <li>On Christmas (Dec 25th) &amp; New Year (Dec 31st), Hotel may charge extra amount for Mandatory gala night dinner from guests (directly payable at hotel - not included in the package cost)</li>
                                <li>If hotel does not provide complimentary breakfast, INR 100 for 2-star, INR 150 for 3-star &amp; INR 250 for 4-star will be provided as Breakfast expenses per person (above 5 years). If you miss complimentary breakfast in the hotel due to early morning sightseeing (before 8 AM), you need to have breakfast outside at own expense.</li>
                                <li>Cab &amp; Driver details will be provided 10 hours before the Trip Start Time</li>
                                <li>In case the cab arrival is delayed on Day 1, you can extend the trip end time on last day up to the duration the cab pickup is delayed</li>
                                <li>In case of vehicle breakdown and issue is not resolved in 2 hours (from the time the issue is reported), we will provide alternate vehicle (or) free accommodation in nearby town with food allowance until the issue is resolved.</li>
                                <li>Usually Hotels don't charge for below 3 years kids, no need to select kids below 3 years while boooking tour. In case of any charges by hotels for below 3y kids, amount needs to be paid directly at the hotel.</li>
                                <li>Refund is issued only in case hotel denies check-in and customer had to book own stay or vehicle could not be provided and customer arranges own transport.</li>
                                <li>If tour is booked with partial advance payment, additional terms can be found here</li>
                                <li>For cab only bookings, additional terms can be found here</li>
                                <li>Below Cancellation Policy is applicable for all tours irrespective of date of booking and mode of booking:</li>
                                <li>Cancellation Policy (Domestic Tours Except Andamans &amp; North East):</li>                    
                                <li>16 days &amp; beyond from date of travel (excluding travel date) - 15% of Order Total is charged as cancellation fee</li>
                                <li>Between 8-15 days from date of travel (excluding travel date) - 50% of Order Total is charged as cancellation fee</li>
                                <li>Between 3-7 days from date of travel (excluding travel date) - 75% of Order Total is charged as cancellation fee</li>
                                <li>No Refund if cancelled within 2 days from date of travel, excluding travel date (sorry, we already paid for your Hotel &amp; Cab by this time)</li>
                                <li>Cancellation Policy (International Tours, Andamans &amp; North East):</li>
                                <li>16 days &amp; beyond from date of travel (excluding travel date) - 50% of Order Total is charged as cancellation fee</li>
                                <li>Between 8-15 days from date of travel (excluding travel date) - 75% of Order Total is charged as cancellation fee</li>
                                <li>No Refund if cancelled within 7 days from date of travel, excluding travel date (sorry, we already paid for your Hotel &amp; Cab by this time)</li>
                            </ul>
                        </div>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>

                </div>
            </div>
        </div>
       
    <?php include("footer.php"); ?> 

        <!-- <script src="https://code.jquery.com/jquery-1.9.1.min.js "></script> -->
        <!-- <script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script> -->
        <!-- <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script> -->
        <script src="<?php echo base_url(); ?>assets/js/slick.js" type="text/javascript"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>
        <!-- <script src="<?php echo base_url(); ?>assets/js/menu.js"></script> -->
        <script>          
           
            $(function () {
                $('.selectpicker').selectpicker();
            });
        </script>


         <script>
            $('.weekend-destinations-slider').slick({
                slidesToShow: 3,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 5000,
                responsive: [

                    {
                        breakpoint: 1399,
                        settings: {
                            slidesToShow: 3
                        }
                    },

                    {
                        breakpoint: 1199,
                        settings: {
                            slidesToShow: 3
                        }
                    }, {
                        breakpoint: 991,
                        settings: {
                            slidesToShow: 1
                        }
                    }, {
                        breakpoint: 767,
                        settings: {
                            slidesToShow: 1
                        }
                    }, {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1
                        }
                    }
                ]
            });

            $('.testimonial-slider').slick({
                slidesToShow: 4,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 5000,
                responsive: [

                    {
                        breakpoint: 1399,
                        settings: {
                            slidesToShow: 3
                        }
                    },

                    {
                        breakpoint: 1199,
                        settings: {
                            slidesToShow: 3
                        }
                    }, {
                        breakpoint: 991,
                        settings: {
                            slidesToShow: 1
                        }
                    }, {
                        breakpoint: 767,
                        settings: {
                            slidesToShow: 1
                        }
                    }, {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1
                        }
                    }
                ]
            });
        </script>

       
        <script>
            var video = document.getElementById("myVideo");
            var btn = document.getElementById("myBtn");

            function myFunction() {
                if (video.paused) {
                    video.play();
                    btn.innerHTML = "Pause";
                } else {
                    video.pause();
                    btn.innerHTML = "Play";
                }
            }
        </script>


    </body>
</html>